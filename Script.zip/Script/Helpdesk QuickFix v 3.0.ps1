﻿


#-------------------------------------------------------------------------------------#
#######################################################################################
#######################################################################################
#######################################################################################

#######################################################################################
################################### Settings ##########################################
#######################################################################################

# Whats Assemblyes to use
# Net Assembly
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

#-------------------------------------------------------------------------------------#
# Form Settings Size, Name, Pos, Icon, Applications ServiceId and Password
# To get this script to work, you will need to insert some values in the formsettings
$ApplicationForm = New-Object System.Windows.Forms.Form
#$ApplicationIconPath = "$PSScriptRoot\Files\logo\logo.jpg"
#$ApplicationForm.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Help File Path
$HelpFileLocation = "$PSScriptRoot\Files\Help\Help.txt"
# XML - File That generates the fields to lvmain
$XMLFile = "$PSScriptRoot\Files\xmltable\Ls.Xml"
[XML]$Script:XML = Get-Content $XMLFile
# XML - File That generates the fields to lvmain
$ApplicationVersion = "V 3.0"
$ApplicationTitle = ""
$ApplicationForm.Text = "$ApplicationTitle $ApplicationVersion" 
$ApplicationForm.StartPosition = "CenterScreen"
$ApplicationForm.Topmost = $false 
$ApplicationForm.Size = "800,600"
$ApplicationFormServiceUserId = ""
$ApplicationFormServiceUserPassword = ""
#######################################################################################
###################################  Server Settings ##################################
#######################################################################################
#
# SMTP Settings
$SmtpAdressToMailServer =  "mailaserver.contoso.com" 
$SmtpFqdn = "@contoso.com"
$SmtpEncoding = "UTF-8"
#-------------------------------------------------------------------------------------#
# 
# Path to fileserver
$FormInstallOpenFileDialogFileBrowserinitialDirectory = "" 



#
# Paths To Dameware, Helpfile, Xml
# DameWare Path
$ApplicationDamewarePath = ""
$FormLocalAdminFieldTextBoxLocalUsernametext = "" 
$FormLocalAdminFieldTextBoxLocalPasswordtext = "" 


#######################################################################################
###################### Standard size on the Buttons,textbar and labels ################
#######################################################################################
# 
# Size Values 
$ValueTextbarSize = "150,50"
$ValueLabelSize = "75,15"
$ValueButtonSize = "75,20"
#-------------------------------------------------------------------------------------#
#######################################################################################
###################################  Context Menu Settings ############################
#######################################################################################
#
# ContextMenu
$ContextMenu = New-Object System.Windows.Forms.ContextMenuStrip
$ContextMenu.Name = "ContextMenu"
$ContextMenu.Size = '188, 114'

######################################################################################
###############################  Context Submenus  ###################################
######################################################################################
######################################################################################
          # ToolStrips Process, End By Name, ProcessId and Email information #
######################################################################################
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#

######################################################################################
#
# Terminate Process By Name
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$CmsProcEndName = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsProcEndName.Name = "CmsProcEndName"
$CmsProcEndName.Size = '187, 22'
$CmsProcEndName.Text = "Terminate With Process-name"
$CmsProcEndName.Visible = $False
$CmsProcEndName.Add_Click({CmsProcEndName}) 
function CmsProcEndName {
$FormCmsProcEndName = New-Object System.Windows.Forms.Form
$FormCmsProcEndName.Text = "Terminate With Process-name" 
$FormCmsProcEndName.StartPosition = "CenterScreen"
$FormCmsProcEndName.Topmost = $false 
$FormCmsProcEndName.Size = "350,100"
$FormCmsProcEndName.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : Process Name
$FormCmsProcEndNameLabelProcessName = New-object System.Windows.Forms.Label   
$FormCmsProcEndNameLabelProcessName.location = "90,5" 
$FormCmsProcEndNameLabelProcessName.size = "250,20"
$FormCmsProcEndNameLabelProcessName.text = "Process Name"
$FormCmsProcEndName.Controls.Add($FormCmsProcEndNameLabelProcessName)
# Textbar Username
$FormCmsProcEndNameTextbarProcessName = New-object System.Windows.Forms.Textbox   
$FormCmsProcEndNameTextbarProcessName.location = "5,30" 
$FormCmsProcEndNameTextbarProcessName.size = "250,20"
$FormCmsProcEndName.Controls.Add($FormCmsProcEndNameTextbarProcessName)
# Terminate Button
$FormCmsProcEndNameButtonTerminate = New-object System.Windows.Forms.Button 
$FormCmsProcEndNameButtonTerminate.text= "Terminate"   
$FormCmsProcEndNameButtonTerminate.location = "265,30" 
$FormCmsProcEndNameButtonTerminate.size = $ValueButtonSize  
$FormCmsProcEndNameButtonTerminate.Add_Click({ FormCmsProcEndNameButtonTerminate }) 
$FormCmsProcEndName.Controls.Add($FormCmsProcEndNameButtonTerminate)
function FormCmsProcEndNameButtonTerminate {
$KillProcessByName = $FormCmsProcEndNameTextbarProcessName.text
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
start-sleep -m  100
If ($PingRequest -eq $true) {
$ApplicationFormStatusBarStatusPanel.Text = "Terminate $KillProcessByName"
$ProcessTerminateByName = (Get-WmiObject Win32_Process -ComputerName $TextbarData | ?{ $_.ProcessName -match $KillProcessByName }).Terminate()

$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

$FormCmsProcEndName.Close()
DownloadActiveProcessOnWorkStation
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;}}
# Initlize CmsProcEndName
$FormCmsProcEndName.Add_Shown({$FormCmsProcEndName.Activate()})
[void] $FormCmsProcEndName.ShowDialog()}
[void]$ContextMenu.Items.Add($CmsProcEndName)

######################################################################################
#
#  Terminate Process By ProcessId
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$CmsProcEndId = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsProcEndId.Name = "CmsProcEndId"
$CmsProcEndId.Size = '187, 22'
$CmsProcEndId.Text = "Terminate With ProcessId"
$CmsProcEndId.Visible = $False
$CmsProcEndId.Add_Click({CmsProcEndId}) 
Function CmsProcEndId {
$FormCmsProcEndId = New-Object System.Windows.Forms.Form
$FormCmsProcEndId.Text = "Terminate With ProcessId"
$FormCmsProcEndId.StartPosition = "CenterScreen"
$FormCmsProcEndId.Topmost = $false 
$FormCmsProcEndId.Size = "350,100"
$FormCmsProcEndId.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : Process Id
$FormCmsProcEndIdLabelProcessId = New-object System.Windows.Forms.Label   
$FormCmsProcEndIdLabelProcessId.location = "90,5" 
$FormCmsProcEndIdLabelProcessId.size = "250,20"
$FormCmsProcEndIdLabelProcessId.text = "Process Id"
$FormCmsProcEndId.Controls.Add($FormCmsProcEndIdLabelProcessId)
# Textbar Process Id
$FormCmsProcEndIdTextbarProcessId = New-object System.Windows.Forms.Textbox   
$FormCmsProcEndIdTextbarProcessId.location = "5,30" 
$FormCmsProcEndIdTextbarProcessId.size = "250,20"
$FormCmsProcEndId.Controls.Add($FormCmsProcEndIdTextbarProcessId)
# Terminate Button Id
$FormCmsProcEndIdProcessIdButtonTerminate = New-object System.Windows.Forms.Button 
$FormCmsProcEndIdProcessIdButtonTerminate.text= "Terminate"   
$FormCmsProcEndIdProcessIdButtonTerminate.location = "265,30" 
$FormCmsProcEndIdProcessIdButtonTerminate.size = $ValueButtonSize  
$FormCmsProcEndIdProcessIdButtonTerminate.Add_Click({ FormCmsProcEndIdProcessIdButtonTerminate }) 
$FormCmsProcEndId.Controls.Add($FormCmsProcEndIdProcessIdButtonTerminate)
function FormCmsProcEndIdProcessIdButtonTerminate {
$KillProcessById = $FormCmsProcEndIdTextbarProcessId.text
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
start-sleep -m  100
If ($PingRequest -eq $true) {
$ApplicationFormStatusBarStatusPanel.Text = "Terminate $KillProcessById"
$ProcessTerminateByID = (Get-WmiObject Win32_Process -ComputerName $TextbarData | ?{ $_.ProcessId -match $KillProcessById }).Terminate()

$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

$FormCmsProcEndId.Close()
DownloadActiveProcessOnWorkStation
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0 }}
# Initlize FormCmsProcEndId
$FormCmsProcEndId.Add_Shown({$FormCmsProcEndId.Activate()})
[void] $FormCmsProcEndId.ShowDialog()}
[void]$ContextMenu.Items.Add($CmsProcEndId)

######################################################################################
#
# Send Process-information as email
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$CmsProcEndSendThisAsEmail = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsProcEndSendThisAsEmail.Name = "CmsProcEndSendThisAsEmail"
$CmsProcEndSendThisAsEmail.Size = '187, 22'
$CmsProcEndSendThisAsEmail.Text = "E-Mail Process-Information"
$CmsProcEndSendThisAsEmail.Visible = $False
$CmsProcEndSendThisAsEmail.Add_Click({ CmsProcEndSendThisAsEmail }) 
function CmsProcEndSendThisAsEmail {
$FormCmsProcEndSendThisAsEmail = New-Object System.Windows.Forms.Form
$FormCmsProcEndSendThisAsEmail.Text = "E-Mail Process-Information" 
$FormCmsProcEndSendThisAsEmail.StartPosition = "CenterScreen"
$FormCmsProcEndSendThisAsEmail.Topmost = $false 
$FormCmsProcEndSendThisAsEmail.Size = "350,100"
$FormCmsProcEndSendThisAsEmail.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : Username
$FormCmsProcEndSendThisAsEmailLabelUsername = New-object System.Windows.Forms.Label   
$FormCmsProcEndSendThisAsEmailLabelUsername.location = "90,5" 
$FormCmsProcEndSendThisAsEmailLabelUsername.size = "250,20"
$FormCmsProcEndSendThisAsEmailLabelUsername.text = "Username"
$FormCmsProcEndSendThisAsEmail.Controls.Add($FormCmsProcEndSendThisAsEmailLabelUsername)
# Textbar Username
$FormCmsProcEndSendThisAsEmailTextbarUsername = New-object System.Windows.Forms.Textbox   
$FormCmsProcEndSendThisAsEmailTextbarUsername.location = "5,30" 
$FormCmsProcEndSendThisAsEmailTextbarUsername.size = "250,20"
$FormCmsProcEndSendThisAsEmail.Controls.Add($FormCmsProcEndSendThisAsEmailTextbarUsername)
# Send Button
$FormCmsProcEndSendThisAsEmailButtonSend = New-object System.Windows.Forms.Button 
$FormCmsProcEndSendThisAsEmailButtonSend.text= "Send E-Mail"   
$FormCmsProcEndSendThisAsEmailButtonSend.location = "265,30" 
$FormCmsProcEndSendThisAsEmailButtonSend.size = $ValueButtonSize  
$FormCmsProcEndSendThisAsEmailButtonSend.Add_Click({ FormCmsProcListSendAsEmail }) 
$FormCmsProcEndSendThisAsEmail.Controls.Add($FormCmsProcEndSendThisAsEmailButtonSend)
function FormCmsProcListSendAsEmail { 
$SmtpServer = $SmtpAdressToMailServer 
$SmtpUser = $ApplicationFormServiceUserId
$smtpPassword = $ApplicationFormServiceUserPassword
$SmtpUsername = $FormCmsProcEndSendThisAsEmailTextbarUsername.text
$SmtpUsernameDomain = $SmtpFqdn
$MailtTo = $SmtpUsername + $SmtpUsernameDomain
$MailFrom = $ApplicationFormServiceUserId
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++

$ApplicationFormStatusBarStatusPanel.Text =  "Sending Process-List to user $MailtTo, Wait"
$MailSubject = "Active Process on $TextbarData"
$MailBodyGetActiveProcess = Get-WmiObject win32_process -ComputerName $TextbarData -ErrorVariable SysError | Sort Name | Format-list -Property Name, ProcessId, CommandLine, CreationDate | out-string -Width 8192
$MailBody = "Active processes On $TextbarData $MailBodyGetActiveProcess"
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $SmtpUser, $($smtpPassword | ConvertTo-SecureString -AsPlainText -Force) 
Send-MailMessage -To "$MailtTo" -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8) -UseSsl -Credential $Credentials

$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

$FormCmsProcEndSendThisAsEmail.Close()}
###################
# Initlize FormCmsProcEndSendThisAsEmail
$FormCmsProcEndSendThisAsEmail.Add_Shown({$FormCmsProcEndSendThisAsEmail.Activate()})
[void] $FormCmsProcEndSendThisAsEmail.ShowDialog()}
[void]$ContextMenu.Items.Add($CmsProcEndSendThisAsEmail)
#------------------------------------------------------------------------------------#
######################################################################################
######################################################################################
######################################################################################
#------------------------------------------------------------------------------------#


######################################################################################
# ToolStrips Install Msi, Exe, Driver, Uninstall With Appname and ProductId          #
######################################################################################
######################################################################################
#
#  App Install Msi
#------------------------------------------------------------------------------------#
$CmsAppInstallMsi = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsAppInstallMsi.Name = "CmsAppInstallMsi"
$CmsAppInstallMsi.Size = '187, 22'
$CmsAppInstallMsi.Text = "Install MSi"
$CmsAppInstallMsi.Visible = $False
$CmsAppInstallMsi.Add_Click({ AppInstallMsi }) 
function AppInstallMsi {
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
start-sleep -m  50
If ($PingRequest -eq $true) { 
$ApplicationFormStatusBarStatusPanel.Text = "Creating Msi-Install Form"
start-sleep -m  50
$ApplicationFormStatusBarStatusPanel.text = "Ready"
# Form Install
$FormInstallMsi = New-Object System.Windows.Forms.Form
$FormInstallMsi.Text = "Install MSI On $TextbarData" 
$FormInstallMsi.StartPosition = "CenterScreen"
$FormInstallMsi.Topmost = $false 
$FormInstallMsi.Size = "400,150"
$FormInstallMsi.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : FilePath
$FormInstallMsiLabelFilePath = New-object System.Windows.Forms.Label   
$FormInstallMsiLabelFilePath.location = "90,5" 
$FormInstallMsiLabelFilePath.size = "250,20"
$FormInstallMsiLabelFilePath.text = "File-Path"
$FormInstallMsi.Controls.Add($FormInstallMsiLabelFilePath)
# Textbar to filepath
$FormInstallMsiTextbarFilePath = New-object System.Windows.Forms.Textbox   
$FormInstallMsiTextbarFilePath.location = "5,30" 
$FormInstallMsiTextbarFilePath.size = "250,20"
$FormInstallMsi.Controls.Add($FormInstallMsiTextbarFilePath)
# Browse Button
$FormInstallBtnBrowseAfterMsiFiles = New-object System.Windows.Forms.Button 
$FormInstallBtnBrowseAfterMsiFiles.text= "Browse"   
$FormInstallBtnBrowseAfterMsiFiles.location = "265,30" 
$FormInstallBtnBrowseAfterMsiFiles.size = $ValueButtonSize  
$FormInstallBtnBrowseAfterMsiFiles.Add_Click({ BrowseAfterMsiFiles }) 
$FormInstallMsi.Controls.Add($FormInstallBtnBrowseAfterMsiFiles)
function BrowseAfterMsiFiles { 
$FormInstallOpenFileDialogFileBrowser = New-object System.Windows.Forms.OpenFileDialog
# Path To the Fileserver
$FormInstallOpenFileDialogFileBrowser.initialDirectory = $FormInstallOpenFileDialogFileBrowserinitialDirectory
$FormInstallOpenFileDialogFileBrowser.Title = "$ApplicationTitle $ApplicationVersion" 
$FormInstallOpenFileDialogFileBrowser.Filter = "Msi files (*.Msi)|*.Msi|All files (*.*)|*.*"
$FormInstallOpenFileDialogFileBrowser.Multiselect = $false
$FormInstallOpenFileDialogFileBrowser.showHelp = $true
$FormInstallOpenFileDialogFileBrowser.ShowDialog() 
foreach($FormInstallOpenFileDialogFileBrowserFilePath in $FormInstallOpenFileDialogFileBrowser.FileNames)
{ $FormInstallMsiTextbarFilePath.text = $FormInstallOpenFileDialogFileBrowserFilePath}}           

# Install Button
$FormInstallBtnInstallMsiFiles = New-object System.Windows.Forms.Button 
$FormInstallBtnInstallMsiFiles.text= "Install"   
$FormInstallBtnInstallMsiFiles.location = "265,90" 
$FormInstallBtnInstallMsiFiles.size = $ValueButtonSize  
$FormInstallBtnInstallMsiFiles.Add_Click({ InstallMsiFiles }) 
$FormInstallMsi.Controls.Add($FormInstallBtnInstallMsiFiles)
function InstallMsiFiles { 
$TextbarData = $ApplicationFormTextBarSearchBar.text
 # Path to local folder for MSI installation
$LocalMsiFolder = "\\$TextbarData\c$\HelpdeskQuickFixMsiFolder" 
$ApplicationFormStatusBarStatusPanel.Text = "Creating local folder"
New-Item $LocalMsiFolder -Type Directory
Start-sleep -m 250

$ApplicationFormStatusBarStatusPanel.Text = "Copying Msi-file"
Copy-Item -Path $FormInstallMsiTextbarFilePath.text -Destination $LocalMsiFolder
Start-sleep -m 250

$ApplicationFormStatusBarStatusPanel.Text = "Searching after Msi-file"
$GetLocalFolderMsiItem =  Get-ChildItem -Path $LocalMsiFolder -Recurse -Include *.Msi
Start-sleep -m 250

$ApplicationFormStatusBarStatusPanel.Text = "Installing Msi-file"
Invoke-Command -ComputerName $TextbarData -ScriptBlock { & cmd /c "msiexec.exe /i $GetLocalFolderMsiItem" /qb ADVANCED_OPTIONS=1 CHANNEL=100}
Start-sleep -m 250
$ApplicationFormStatusBarStatusPanel.Text = "Task Completed"

  
$FormInstallMsi.Close()

}
###################
# Initlize FormInstallMsi
$FormInstallMsi.Add_Shown({$FormInstallMsi.Activate()})
[void] $FormInstallMsi.ShowDialog()
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;}}
[void]$ContextMenu.Items.Add($CmsAppInstallMsi)

#------------------------------------------------------------------------------------#
######################################################################################
#
#  App Install Exe
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$CmsAppInstallExe = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsAppInstallExe.Name = "CmsAppInstallExe"
$CmsAppInstallExe.Size = '187, 22'
$CmsAppInstallExe.Text = "Install Exe"
$CmsAppInstallExe.Visible = $False
$CmsAppInstallExe.Add_Click({ AppInstallExe }) 
function AppInstallExe  {
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
If ($PingRequest -eq $true) { 
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Creating Exe-Install Form"
$ApplicationFormProgressBar.Value ++
start-sleep -m 50
$ApplicationFormStatusBarStatusPanel.text = "Task Completed, Exe-Install Form Is Now Created " 
$ApplicationFormProgressBar.Value ++
start-sleep -m 50
$ApplicationFormProgressBar.Value ++
start-sleep -m 50
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

$FormInstallExe = New-Object System.Windows.Forms.Form
$FormInstallExe.Text = "Install On Exe $TextbarData" 
$FormInstallExe.StartPosition = "CenterScreen"
$FormInstallExe.Topmost = $false 
$FormInstallExe.Size = "400,150"
$FormInstallExe.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")

# Label : FilePath
$FormInstallExeLabelFilePath = New-object System.Windows.Forms.Label   
$FormInstallExeLabelFilePath.location = "90,5" 
$FormInstallExeLabelFilePath.size = "250,20"
$FormInstallExeLabelFilePath.text = "File-Path"
$FormInstallExe.Controls.Add($FormInstallExeLabelFilePath)

# Textbar to filepath
$FormInstallExeTextbarFilePath = New-object System.Windows.Forms.Textbox   
$FormInstallExeTextbarFilePath.location = "5,30" 
$FormInstallExeTextbarFilePath.size = "250,20"
$FormInstallExe.Controls.Add($FormInstallExeTextbarFilePath)

# Browse Button
$FormInstallExeBtnBrowseAfterExeFiles = New-object System.Windows.Forms.Button 
$FormInstallExeBtnBrowseAfterExeFiles.text= "Browse"   
$FormInstallExeBtnBrowseAfterExeFiles.location = "265,30" 
$FormInstallExeBtnBrowseAfterExeFiles.size = $ValueButtonSize  
$FormInstallExeBtnBrowseAfterExeFiles.Add_Click({ BrowseAfterExeFiles }) 
$FormInstallExe.Controls.Add($FormInstallExeBtnBrowseAfterExeFiles)
function BrowseAfterExeFiles { 
$FormInstallOpenFileDialogFileBrowserExe = New-object System.Windows.Forms.OpenFileDialog
$FormInstallOpenFileDialogFileBrowserExe.initialDirectory = $FormInstallOpenFileDialogFileBrowserinitialDirectory
$FormInstallOpenFileDialogFileBrowserExe.Title = "$ApplicationTitle $ApplicationVersion" 
$FormInstallOpenFileDialogFileBrowserExe.Filter = "Exe files (*.Exe)|*.Exe|All files (*.*)|*.*"
$FormInstallOpenFileDialogFileBrowserExe.Multiselect = $false
$FormInstallOpenFileDialogFileBrowserExe.showHelp = $true
$FormInstallOpenFileDialogFileBrowserExe.ShowDialog() 
foreach($FormInstallOpenFileDialogFileBrowserExeFilePath in $FormInstallOpenFileDialogFileBrowserExe.FileNames)
{ $FormInstallExeTextbarFilePath.text = $FormInstallOpenFileDialogFileBrowserExeFilePath }}           
 
# Install Button
$FormInstallExeBtnInstallExeFiles = New-object System.Windows.Forms.Button 
$FormInstallExeBtnInstallExeFiles.text= "Install"   
$FormInstallExeBtnInstallExeFiles.location = "265,90" 
$FormInstallExeBtnInstallExeFiles.size = $ValueButtonSize  
$FormInstallExeBtnInstallExeFiles.Add_Click({ InstallMsiFiles }) 
$FormInstallExe.Controls.Add($FormInstallExeBtnInstallExeFiles)
function InstallMsiFiles { 

$TextbarData = $ApplicationFormTextBarSearchBar.text
 # Path to local folder for MSI installation
$LocalExeFolder = "\\$TextbarData\c$\HelpdeskQuickFixExeFolder" 
$ApplicationFormStatusBarStatusPanel.Text = "Creating local folder"
New-Item $LocalExeFolder -Type Directory
Start-sleep -m 250

$ApplicationFormStatusBarStatusPanel.Text = "Copying Exe-file"
Copy-Item -Path $FormInstallExeTextbarFilePath.text -Destination $LocalExeFolder
Start-sleep -m 250

$ApplicationFormStatusBarStatusPanel.Text = "Searching after Msi-file"
$GetLocalFolderMsiItem =  Get-ChildItem -Path $LocalExeFolder -Recurse -Include *.Exe
Start-sleep -m 250

$ApplicationFormStatusBarStatusPanel.Text = "Installing Msi-file"
Invoke-Command -ComputerName $TextbarData -ScriptBlock { & cmd /c "msiexec.exe /i $GetLocalFolderMsiItem" /qb ADVANCED_OPTIONS=1 CHANNEL=100}
Start-sleep -m 250
$ApplicationFormStatusBarStatusPanel.Text = "Task Completed"

  



$FormInstallExeBtnInstallExeFilesProcess = (Get-WMIObject -ComputerName $TextbarData -List | Where-Object -FilterScript {$_.Name -eq "Win32_Product"}).Install($FormInstallOpenFileDialogFileBrowserExe) | out-null
$CmsSrvSendAsMailForm.Close()
}

###################
# Initlize the Form
$FormInstallExe.Add_Shown({$FormInstallExe.Activate()})
[void] $FormInstallExe.ShowDialog()

} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
}}
[void]$ContextMenu.Items.Add($CmsAppInstallExe)

#------------------------------------------------------------------------------------#
######################################################################################
#  App Install Drivers
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$CmsAppInstallDrivers = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsAppInstallDrivers.Name = "CmsAppInstallDrivers"
$CmsAppInstallDrivers.Size = '187, 22'
$CmsAppInstallDrivers.Text = "Install Driver"
$CmsAppInstallDrivers.Visible = $False
$CmsAppInstallDrivers.Add_Click({ AppInstallDrivers }) 
function AppInstallDrivers  {
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
start-sleep -m  50
If ($PingRequest -eq $true) { 
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Creating Driver-Install Form"

$FormInstallDriver = New-Object System.Windows.Forms.Form
$FormInstallDriver.Text = "Install On Driver $TextbarData" 
$FormInstallDriver.StartPosition = "CenterScreen"
$FormInstallDriver.Topmost = $false 
$FormInstallDriver.Size = "400,150"
$FormInstallDriver.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : FilePath
$FormInstallDriverLabelFilePath = New-object System.Windows.Forms.Label   
$FormInstallDriverLabelFilePath.location = "90,5" 
$FormInstallDriverLabelFilePath.size = "250,20"
$FormInstallDriverLabelFilePath.text = "File-Path"
$FormInstallDriver.Controls.Add($FormInstallDriverLabelFilePath)
# Textbar to filepath
$FormInstallDriverTextbarFilePath = New-object System.Windows.Forms.Textbox   
$FormInstallDriverTextbarFilePath.location = "5,30" 
$FormInstallDriverTextbarFilePath.size = "250,20"
$FormInstallDriver.Controls.Add($FormInstallDriverTextbarFilePath)
# Browse Button
$FormInstallDriverBtnBrowseAfterDriverFiles = New-object System.Windows.Forms.Button 
$FormInstallDriverBtnBrowseAfterDriverFiles.text= "Browse"   
$FormInstallDriverBtnBrowseAfterDriverFiles.location = "265,30" 
$FormInstallDriverBtnBrowseAfterDriverFiles.size = $ValueButtonSize  
$FormInstallDriverBtnBrowseAfterDriverFiles.Add_Click({ BrowseAfterDriverFiles }) 
$FormInstallDriver.Controls.Add($FormInstallDriverBtnBrowseAfterDriverFiles)
function BrowseAfterDriverFiles { 
$FormInstallOpenFileDialogFileBrowserDriver = New-object System.Windows.Forms.OpenFileDialog
$FormInstallOpenFileDialogFileBrowserDriver.initialDirectory = $FormInstallOpenFileDialogFileBrowserinitialDirectory
$FormInstallOpenFileDialogFileBrowserDriver.Title = "$ApplicationTitle $ApplicationVersion" 
$FormInstallOpenFileDialogFileBrowserDriver.Filter = "Inf files (*.Inf)|*.Inf|All files (*.*)|*.*"
$FormInstallOpenFileDialogFileBrowserDriver.Multiselect = $false
$FormInstallOpenFileDialogFileBrowserDriver.showHelp = $true
$FormInstallOpenFileDialogFileBrowserDriver.ShowDialog() 
foreach($FormInstallOpenFileDialogFileBrowserDriverFilePath in $FormInstallOpenFileDialogFileBrowserDriver.FileNames)
{ $FormInstallDriverTextbarFilePath.text = $FormInstallOpenFileDialogFileBrowserDriverFilePath }}           

# Install Button
$FormInstallDriverBtnInstallDriverFiles = New-object System.Windows.Forms.Button 
$FormInstallDriverBtnInstallDriverFiles.text= "Install"   
$FormInstallDriverBtnInstallDriverFiles.location = "265,90" 
$FormInstallDriverBtnInstallDriverFiles.size = $ValueButtonSize  
$FormInstallDriverBtnInstallDriverFiles.Add_Click({ InstallDriverFiles }) 
$FormInstallDriver.Controls.Add($FormInstallDriverBtnInstallDriverFiles)
function InstallDriverFiles { 
$FormInstallExeBtnInstallDriverFilesProcess = " | out-null "
$CmsSrvSendAsMailForm.Close()
}

# Initlize FormInstallDriver
$FormInstallDriver.Add_Shown({$FormInstallDriver.Activate()})
[void] $FormInstallDriver.ShowDialog()

} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;}}
[void]$ContextMenu.Items.Add($CmsAppInstallDrivers)

######################################################################################
#
#  Send Installed Apps as email
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$CmsAppInstallSendThisAsEmail = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsAppInstallSendThisAsEmail.Name = "CmsAppInstallSendThisAsEmail"
$CmsAppInstallSendThisAsEmail.Size = '187, 22'
$CmsAppInstallSendThisAsEmail.Text = "E-Mail Installed Apps"
$CmsAppInstallSendThisAsEmail.Visible = $False
$CmsAppInstallSendThisAsEmail.Add_Click({ CmsAppInstallSendThisAsEmail }) 
function CmsAppInstallSendThisAsEmail {

$FormCmsAppInstallSendThisAsEmail = New-Object System.Windows.Forms.Form
$FormCmsAppInstallSendThisAsEmail.Text = "E-Mail Installed Apps" 
$FormCmsAppInstallSendThisAsEmail.StartPosition = "CenterScreen"
$FormCmsAppInstallSendThisAsEmail.Topmost = $false 
$FormCmsAppInstallSendThisAsEmail.Size = "350,100"
$FormCmsAppInstallSendThisAsEmail.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : Username
$FormCmsAppInstallSendThisAsEmailLabelUsername = New-object System.Windows.Forms.Label   
$FormCmsAppInstallSendThisAsEmailLabelUsername.location = "90,5" 
$FormCmsAppInstallSendThisAsEmailLabelUsername.size = "250,20"
$FormCmsAppInstallSendThisAsEmailLabelUsername.text = "Username"
$FormCmsAppInstallSendThisAsEmail.Controls.Add($FormCmsAppInstallSendThisAsEmailLabelUsername)
# Textbar Username
$FormCmsAppInstallSendThisAsEmailTextbarUsername = New-object System.Windows.Forms.Textbox   
$FormCmsAppInstallSendThisAsEmailTextbarUsername.location = "5,30" 
$FormCmsAppInstallSendThisAsEmailTextbarUsername.size = "250,20"
$FormCmsAppInstallSendThisAsEmail.Controls.Add($FormCmsAppInstallSendThisAsEmailTextbarUsername)
# Send Button
$FormCmsAppInstallSendThisAsEmailButtonSend = New-object System.Windows.Forms.Button 
$FormCmsAppInstallSendThisAsEmailButtonSend.text= "Send E-Mail"   
$FormCmsAppInstallSendThisAsEmailButtonSend.location = "265,30" 
$FormCmsAppInstallSendThisAsEmailButtonSend.size = $ValueButtonSize  
$FormCmsAppInstallSendThisAsEmailButtonSend.Add_Click({ FormCmsAppInstallSendThisAsEmail }) 
$FormCmsAppInstallSendThisAsEmail.Controls.Add($FormCmsAppInstallSendThisAsEmailButtonSend)
function FormCmsAppInstallSendThisAsEmail {
$SmtpServer = $SmtpAdressToMailServer 
$SmtpUser = $ApplicationFormServiceUserId
$smtpPassword = $ApplicationFormServiceUserPassword
$SmtpUsername = $FormCmsAppInstallSendThisAsEmailTextbarUsername.text
$SmtpUsernameDomain = $SmtpFqdn
$MailtTo = $SmtpUsername + $SmtpUsernameDomain
$MailFrom = $ApplicationFormServiceUserId
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++

$ApplicationFormStatusBarStatusPanel.Text =  "Sending Information Installed Apps To user $MailtTo"
$MailSubject = "Installed Apps on $TextbarData" 
$MailBodyGetInstalledApps = Get-WmiObject win32_Product  -ComputerName $TextbarData -ErrorVariable SysError | Sort Name | Format-list -Property Name, Vendor, Caption, Version, IdentifyingNumber | out-string -Width 8192
$MailBody = "Lista på Installerade Applikationer på $TextbarData $MailBodyGetInstalledApps"
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $SmtpUser, $($smtpPassword | ConvertTo-SecureString -AsPlainText -Force) 
Send-MailMessage -To "$MailtTo" -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8) -UseSsl -Credential $Credentials

$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

$FormCmsAppInstallSendThisAsEmail.Close()}
# Initlize FormCmsAppInstallSendThisAsEmail
$FormCmsAppInstallSendThisAsEmail.Add_Shown({$FormCmsAppInstallSendThisAsEmail.Activate()})
[void] $FormCmsAppInstallSendThisAsEmail.ShowDialog()}
[void]$ContextMenu.Items.Add($CmsAppInstallSendThisAsEmail)

######################################################################################
#
#  Uninstall Apps With Name
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$CmsAppUninstallByName = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsAppUninstallByName.Name = "CmsAppUninstallByName"
$CmsAppUninstallByName.Size = '187, 22'
$CmsAppUninstallByName.Text = "Uninstall With App-Name"
$CmsAppUninstallByName.Visible = $False
$CmsAppUninstallByName.Add_Click({ AppCmsAppUninstallByName }) 
function AppCmsAppUninstallByName {

$FormCmsAppUninstallByName = New-Object System.Windows.Forms.Form
$FormCmsAppUninstallByName.Text = "Name - Uninstall" 
$FormCmsAppUninstallByName.StartPosition = "CenterScreen"
$FormCmsAppUninstallByName.Topmost = $false 
$FormCmsAppUninstallByName.Size = "350,100"
$FormCmsAppUninstallByName.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : App Name
$FormFormCmsAppUninstallByNameLabelName = New-object System.Windows.Forms.Label   
$FormFormCmsAppUninstallByNameLabelName.location = "90,5" 
$FormFormCmsAppUninstallByNameLabelName.size = "250,20"
$FormFormCmsAppUninstallByNameLabelName.text = " Type App Name "
$FormCmsAppUninstallByName.Controls.Add($FormFormCmsAppUninstallByNameLabelName)
# Textbar App Name
$FormCmsAppUninstallByNameTextbarName = New-object System.Windows.Forms.Textbox   
$FormCmsAppUninstallByNameTextbarName.location = "5,30" 
$FormCmsAppUninstallByNameTextbarName.size = "250,20"
$FormCmsAppUninstallByName.Controls.Add($FormCmsAppUninstallByNameTextbarName)
# Uninstall Button Name
$FormCmsAppUninstallByNameUninstallButton = New-object System.Windows.Forms.Button 
$FormCmsAppUninstallByNameUninstallButton.text= "Uninstall"   
$FormCmsAppUninstallByNameUninstallButton.location = "265,30" 
$FormCmsAppUninstallByNameUninstallButton.size = $ValueButtonSize  
$FormCmsAppUninstallByNameUninstallButton.Add_Click({ FormCmsAppUninstallByNameFunction }) 
$FormCmsAppUninstallByName.Controls.Add($FormCmsAppUninstallByNameUninstallButton)
function FormCmsAppUninstallByNameFunction { 
$TextbarData = $ApplicationFormTextBarSearchBar.text
$UninstallNameOfApplication = $FormCmsAppUninstallGuidTextbarGuid.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
If ($PingRequest -eq $true) { 
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Starting Uninstall-Process On $TextbarData"
$ProcessUninstallName = Get-WmiObject win32_product -ComputerName $TextbarData | Where-Object {$_.name -match $UninstallNameOfApplication}
$ProcessUninstallName.uninstall() | Select-Object -Property returnvalue

$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

$FormCmsAppUninstallByName.Close()
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;}}
# Initlize FormCmsAppUninstallByName
$FormCmsAppUninstallByName.Add_Shown({$FormCmsAppUninstallByName.Activate()})
[void] $FormCmsAppUninstallByName.ShowDialog()}
[void]$ContextMenu.Items.Add($CmsAppUninstallByName)

######################################################################################
#
#  Uninstall Apps With Product ID
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$CmsAppUninstallGuid = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsAppUninstallGuid.Name = "CmsAppUninstallGuid"
$CmsAppUninstallGuid.Size = '187, 22'
$CmsAppUninstallGuid.Text = "Uninstall By Guid"
$CmsAppUninstallGuid.Visible = $False
$CmsAppUninstallGuid.Add_Click({ AppUninstallGuidFunction }) 
function AppUninstallGuidFunction {
$FormCmsAppUninstallGuid = New-Object System.Windows.Forms.Form
$FormCmsAppUninstallGuid.Text = "Guid - Uninstall" 
$FormCmsAppUninstallGuid.StartPosition = "CenterScreen"
$FormCmsAppUninstallGuid.Topmost = $false 
$FormCmsAppUninstallGuid.Size = "350,100"
$FormCmsAppUninstallGuid.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : Username
$FormCmsAppUninstallGuidLabelGuid = New-object System.Windows.Forms.Label   
$FormCmsAppUninstallGuidLabelGuid.location = "90,5" 
$FormCmsAppUninstallGuidLabelGuid.size = "250,20"
$FormCmsAppUninstallGuidLabelGuid.text = "Guid Number"
$FormCmsAppUninstallGuid.Controls.Add($FormCmsAppUninstallGuidLabelGuid)
# Textbar Guid
$FormCmsAppUninstallGuidTextbarGuid = New-object System.Windows.Forms.Textbox   
$FormCmsAppUninstallGuidTextbarGuid.location = "5,30" 
$FormCmsAppUninstallGuidTextbarGuid.size = "250,20"
$FormCmsAppUninstallGuid.Controls.Add($FormCmsAppUninstallGuidTextbarGuid)
# Uninstall Guid Button
$FormCmsAppUninstallGuidButtonGuidUninstall = New-object System.Windows.Forms.Button 
$FormCmsAppUninstallGuidButtonGuidUninstall.text= "Uninstall"   
$FormCmsAppUninstallGuidButtonGuidUninstall.location = "265,30" 
$FormCmsAppUninstallGuidButtonGuidUninstall.size = $ValueButtonSize  
$FormCmsAppUninstallGuidButtonGuidUninstall.Add_Click({ FormCmsAppUninstallGuidFunction }) 
$FormCmsAppUninstallGuid.Controls.Add($FormCmsAppUninstallGuidButtonGuidUninstall)
function FormCmsAppUninstallGuidFunction { 
$TextbarData = $ApplicationFormTextBarSearchBar.text
$UninstallGuidApplication = $FormCmsAppUninstallGuidTextbarGuid.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
If ($PingRequest -eq $true) { 
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Starting Uninstall-Process On $TextbarData"
$ProcessUninstallGuidApplication = Get-WmiObject win32_product -ComputerName $TextbarData | Where-Object {$_.IdentifyingNumber -match $UninstallGuidApplication}
$ProcessUninstallGuidApplication.uninstall() | Select-Object -Property returnvalue

$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$FormCmsAppUninstallGuid.Close()

} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;}}
# Initlize FormCmsAppUninstallGuid
$FormCmsAppUninstallGuid.Add_Shown({$FormCmsAppUninstallGuid.Activate()})
[void] $FormCmsAppUninstallGuid.ShowDialog()}
[void]$ContextMenu.Items.Add($CmsAppUninstallGuid)
#------------------------------------------------------------------------------------#
######################################################################################
######################################################################################
######################################################################################
#------------------------------------------------------------------------------------#



######################################################################################
#
#  App - Service Start, Stop, Restart
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$CmsSrvStart = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsSrvStart.Name = "CmsSrvStartStopRestart"
$CmsSrvStart.Size = '187, 22'
$CmsSrvStart.Text = "Service Options"
$CmsSrvStart.Visible = $False
$CmsSrvStart.Add_Click({ CmsSrvStartService }) 
function CmsSrvStartService {
$CmsSrvStartService = $någontextbar.text
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
start-sleep -m  100
If ($PingRequest -eq $true) {
$ApplicationFormStatusBarStatusPanel.Text = "Ping Successful, Starting Form-Service"

#Generated Form  
$FormServiceOptions = New-Object System.Windows.Forms.Form
$FormServiceOptions.Text = "Service Options On $TextbarData" 
$FormServiceOptions.StartPosition = "CenterScreen"
$FormServiceOptions.Topmost = $false 
$FormServiceOptions.Size = "350,200"
$FormServiceOptions.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")

# Checkbox Start
$FormServiceOptionsCheckBoxStart = New-object System.Windows.Forms.Checkbox
$FormServiceOptionsCheckBoxStart.text = "Start Service"
$FormServiceOptionsCheckBoxStart.location = "5,50" 
$FormServiceOptionsCheckBoxStart.size = "90,15" 
$FormServiceOptions.Controls.Add($FormServiceOptionsCheckBoxStart)

# Checkbox Restart
$FormServiceOptionsCheckBoxReStart = New-object System.Windows.Forms.Checkbox
$FormServiceOptionsCheckBoxReStart.text = "Restart Service"
$FormServiceOptionsCheckBoxReStart.location = "5,70" 
$FormServiceOptionsCheckBoxReStart.size = "110,15" 
$FormServiceOptions.Controls.Add($FormServiceOptionsCheckBoxReStart)

# Checkbox Stop
$FormServiceOptionsCheckBoxStop = New-object System.Windows.Forms.Checkbox
$FormServiceOptionsCheckBoxStop.text = "Stop Service"
$FormServiceOptionsCheckBoxStop.location = "5,90" 
$FormServiceOptionsCheckBoxStop.size = "110,15" 
$FormServiceOptions.Controls.Add($FormServiceOptionsCheckBoxStop)

# Label Service Name 
$FormServiceOptionsLabelServiceName = New-object System.Windows.Forms.Label
$FormServiceOptionsLabelServiceName.text = "Service Name"
$FormServiceOptionsLabelServiceName.location = "5,5" 
$FormServiceOptionsLabelServiceName.size = "110,15" 
$FormServiceOptions.Controls.Add($FormServiceOptionsLabelServiceName)

# Textbar Service Name 
$FormServiceOptionsTextbarServiceName = New-object System.Windows.Forms.textbox
$FormServiceOptionsTextbarServiceName.location = "5,20" 
$FormServiceOptionsTextbarServiceName.size = "250,15" 
$FormServiceOptions.Controls.Add($FormServiceOptionsTextbarServiceName)

# Button Go 
$FormServiceOptionsButtonGo = New-object System.Windows.Forms.button
$FormServiceOptionsButtonGo.location = "125,110" 
$FormServiceOptionsButtonGo.size = "75,20" 
$FormServiceOptionsButtonGo.text = "Go" 
$FormServiceOptions.Controls.Add($FormServiceOptionsButtonGo)
$FormServiceOptionsButtonGo.Add_Click({ FormServiceOptionsButtonGo })   
function FormServiceOptionsButtonGo { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text 
$ServiceName = $FormServiceOptionsTextbarServiceName.Text

if ($FormServiceOptionsCheckBoxStart.Checked) { (Get-Service -ComputerName $TextbarData -Name $ServiceName).Start() 
$ApplicationFormStatusBarStatusPanel.text = "Starting Service $ServiceName "
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$FormServiceOptions.Close()
DownloadServicesOnWorkStation
}

if ($FormServiceOptionsCheckBoxReStart.Checked) { (Get-Service -ComputerName $TextbarData -Name $ServiceName).Restart() 
$ApplicationFormStatusBarStatusPanel.text = "Restart Service $ServiceName "
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$FormServiceOptions.Close()
DownloadServicesOnWorkStation
}

if ($FormServiceOptionsCheckBoxStop.Checked) { (Get-Service -ComputerName $TextbarData -Name $ServiceName).Stop() 
$ApplicationFormStatusBarStatusPanel.text = "Stop Service $ServiceName "
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$FormServiceOptions.Close()
DownloadServicesOnWorkStation
}

}
# Initlize the Form
$FormServiceOptions.Add_Shown({$FormServiceOptions.Activate()})
[void] $FormServiceOptions.ShowDialog()
$ApplicationFormStatusBarStatusPanel.Text = "Ready"
start-sleep -m  100

} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
 }}
[void]$ContextMenu.Items.Add($CmsSrvStart)

######################################################################################
#
#  Service Send As Mail Process By ProcessId
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$CmsSrvSendAsMail = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsSrvSendAsMail.Name = "CmsSrvSendAsMail"
$CmsSrvSendAsMail.Size = '187, 22'
$CmsSrvSendAsMail.Text = "Send as email"
$CmsSrvSendAsMail.Visible = $False
$CmsSrvSendAsMail.Add_Click({ CmsSrvSendAsMail }) 
function CmsSrvSendAsMail {
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
start-sleep -m  100
If ($PingRequest -eq $true) {
$ApplicationFormStatusBarStatusPanel.Text = "Ping Successful, "
start-sleep -m  100

$CmsSrvSendAsMailForm = New-Object System.Windows.Forms.Form
$CmsSrvSendAsMailForm.Text = "E-Mail Services" 
$CmsSrvSendAsMailForm.StartPosition = "CenterScreen"
$CmsSrvSendAsMailForm.Topmost = $false 
$CmsSrvSendAsMailForm.Size = "350,100"
$CmsSrvSendAsMailForm.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")

# Label : Username
$CmsSrvSendAsMailFormLabelUsername = New-object System.Windows.Forms.Label   
$CmsSrvSendAsMailFormLabelUsername.location = "90,5" 
$CmsSrvSendAsMailFormLabelUsername.size = "250,20"
$CmsSrvSendAsMailFormLabelUsername.text = "Username"
$CmsSrvSendAsMailForm.Controls.Add($CmsSrvSendAsMailFormLabelUsername)

# Textbar Username
$CmsSrvSendAsMailFormTextbarUsername = New-object System.Windows.Forms.Textbox   
$CmsSrvSendAsMailFormTextbarUsername.location = "5,30" 
$CmsSrvSendAsMailFormTextbarUsername.size = "250,20"
$CmsSrvSendAsMailForm.Controls.Add($CmsSrvSendAsMailFormTextbarUsername)

# Send Button
$CmsSrvSendAsMailFormEmailButtonSend = New-object System.Windows.Forms.Button 
$CmsSrvSendAsMailFormEmailButtonSend.text= "Send E-Mail"   
$CmsSrvSendAsMailFormEmailButtonSend.location = "265,30" 
$CmsSrvSendAsMailFormEmailButtonSend.size = $ValueButtonSize  
$CmsSrvSendAsMailFormEmailButtonSend.Add_Click({ CmsSrvSendAsMailFormSendThisAsEmail }) 
$CmsSrvSendAsMailForm.Controls.Add($CmsSrvSendAsMailFormEmailButtonSend)
function CmsSrvSendAsMailFormSendThisAsEmail {

$SmtpServer = $SmtpAdressToMailServer 
$SmtpUser = $ApplicationFormServiceUserId
$smtpPassword = $ApplicationFormServiceUserPassword
$SmtpUsername = $CmsSrvSendAsMailFormTextbarUsername.text
$SmtpUsernameDomain = $SmtpFqdn
$MailtTo = $SmtpUsername + $SmtpUsernameDomain
$MailFrom = $ApplicationFormServiceUserId

$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++

$ApplicationFormStatusBarStatusPanel.Text =  "Sending Service-Information To User $MailtTo"
$MailSubject = "Services on $TextbarData"
$MailBodyGetServices = "Get-WmiObject win32_Product  -ComputerName $TextbarData -ErrorVariable SysError | Sort Name | Format-list -Property Name, Vendor, Caption, Version, IdentifyingNumber | out-string -Width 8192"
$MailBody = "Lista tjänster på $TextbarData $MailBodyGetServices"
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $SmtpUser, $($smtpPassword | ConvertTo-SecureString -AsPlainText -Force) 
Send-MailMessage -To "$MailtTo" -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8) -UseSsl -Credential $Credentials



$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"


$CmsSrvSendAsMailForm.Close()}
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0 }
# Initlize FormCmsAppInstallSendThisAsEmail
$CmsSrvSendAsMailForm.Add_Shown({$CmsSrvSendAsMailForm.Activate()})
[void] $CmsSrvSendAsMailForm.ShowDialog()}
[void]$ContextMenu.Items.Add($CmsSrvSendAsMail)
#------------------------------------------------------------------------------------#
######################################################################################
######################################################################################
######################################################################################
#------------------------------------------------------------------------------------#

######################################################################################
                      # ToolStrips StartUp and Email information #
######################################################################################

######################################################################################
#
#  StartUp Menu, Options and Email
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#

$CmsStartupRemove = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsStartupRemove.Name = "CmsStartupRemove"
$CmsStartupRemove.Size = '187, 22'
$cmsStartupRemove.Text = "Remove Startup Item"
$CmsStartupRemove.Visible = $False
$CmsStartupRemove.Add_Click({ StartupRemoveFunction }) 
function StartupRemoveFunction { 
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
If ($PingRequest -eq $true) { 
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Starting to remove Startup-Object On $TextbarData"
$ApplicationFormStatusBarStatusPanel.Text = "Skapa en invoke command för detta"

DownloadStartupOnWorkStation
}}
[void]$ContextMenu.Items.Add($CmsStartupRemove)

######################################################################################
#
#  Send Startup information as email
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#

$CmsStartupRemoveSendThisAsEmail = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsStartupRemoveSendThisAsEmail.Name = "CmsStartupRemoveSendThisAsEmail"
$CmsStartupRemoveSendThisAsEmail.Size = '187, 22'
$CmsStartupRemoveSendThisAsEmail.Text = "Send E-Mail"
$CmsStartupRemoveSendThisAsEmail.Visible = $False
$CmsStartupRemoveSendThisAsEmail.Add_Click({ CmsStartupRemoveSendThisAsEmail }) 
function CmsStartupRemoveSendThisAsEmail { 
$FormCmsStartupSendThisAsEmail = New-Object System.Windows.Forms.Form
$FormCmsStartupSendThisAsEmail.Text = "E-Mail Startup-Information" 
$FormCmsStartupSendThisAsEmail.StartPosition = "CenterScreen"
$FormCmsStartupSendThisAsEmail.Topmost = $false 
$FormCmsStartupSendThisAsEmail.Size = "350,100"
$FormCmsStartupSendThisAsEmail.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : Username
$FormCmsStartupSendThisAsEmailLabelUsername = New-object System.Windows.Forms.Label   
$FormCmsStartupSendThisAsEmailLabelUsername.location = "90,5" 
$FormCmsStartupSendThisAsEmailLabelUsername.size = "250,20"
$FormCmsStartupSendThisAsEmailLabelUsername.text = "Username"
$FormCmsStartupSendThisAsEmail.Controls.Add($FormCmsStartupSendThisAsEmailLabelUsername)
# Textbar Username
$FormCmsStartupSendThisAsEmailTextbarUsername = New-object System.Windows.Forms.Textbox   
$FormCmsStartupSendThisAsEmailTextbarUsername.location = "5,30" 
$FormCmsStartupSendThisAsEmailTextbarUsername.size = "250,20"
$FormCmsStartupSendThisAsEmail.Controls.Add($FormCmsStartupSendThisAsEmailTextbarUsername)
# Send Button
$FormCmsStartupSendThisAsEmailButtonSend = New-object System.Windows.Forms.Button 
$FormCmsStartupSendThisAsEmailButtonSend.text= "Send E-Mail"   
$FormCmsStartupSendThisAsEmailButtonSend.location = "265,30" 
$FormCmsStartupSendThisAsEmailButtonSend.size = $ValueButtonSize  
$FormCmsStartupSendThisAsEmailButtonSend.Add_Click({ FormCmsStartupSendThisAsEmail }) 
$FormCmsStartupSendThisAsEmail.Controls.Add($FormCmsStartupSendThisAsEmailButtonSend)
function FormCmsStartupSendThisAsEmail { 
$SmtpServer = $SmtpAdressToMailServer 
$SmtpUser = $ApplicationFormServiceUserId
$smtpPassword = $ApplicationFormServiceUserPassword
$SmtpUsername = $FormCmsStartupSendThisAsEmailTextbarUsername.text
$SmtpUsernameDomain = $SmtpFqdn
$MailtTo = $SmtpUsername + $SmtpUsernameDomain
$MailFrom = $ApplicationFormServiceUserId
$TextbarData = $ApplicationFormTextBarSearchBar.text

$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++

$ApplicationFormStatusBarStatusPanel.Text =  "Sending Startup-information to user $MailtTo, Wait"
$MailSubject = "Startup-information  on $TextbarData"
$MailBodyGetStartup = Get-WmiObject Win32_StartupCommand -ComputerName $TextbarData -ErrorVariable SysError | Sort User | Format-list User, Command, Caption  | out-string -Width 8192
$MailBody = "Startup-information On $TextbarData $MailBodyGetStartup"
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $SmtpUser, $($smtpPassword | ConvertTo-SecureString -AsPlainText -Force) 
Send-MailMessage -To "$MailtTo" -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8) -UseSsl -Credential $Credentials


$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

$FormCmsStartupSendThisAsEmail.Close()}

###################
# Initlize FormCmsStartupSendThisAsEmail
$FormCmsStartupSendThisAsEmail.Add_Shown({$FormCmsStartupSendThisAsEmail.Activate()})
[void] $FormCmsStartupSendThisAsEmail.ShowDialog()}
[void]$ContextMenu.Items.Add($CmsStartupRemoveSendThisAsEmail)

#------------------------------------------------------------------------------------#
######################################################################################
######################################################################################
######################################################################################
#------------------------------------------------------------------------------------#

######################################################################################
                      # ToolStrips SystemInfo and Email information #
######################################################################################

######################################################################################
#
#  SystemInfo Menu, Options and Email
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#

######################################################################################
#
#  Send SystemInfo information as email
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#

$CmsSystemInfoSendThisAsEmail = New-Object System.Windows.Forms.ToolStripMenuItem
$CmsSystemInfoSendThisAsEmail.Name = "CmsSystemInfoSendThisAsEmail"
$CmsSystemInfoSendThisAsEmail.Size = '187, 22'
$CmsSystemInfoSendThisAsEmail.Text = "Send E-Mail"
$CmsSystemInfoSendThisAsEmail.Visible = $False
$CmsSystemInfoSendThisAsEmail.Add_Click({ CmsSystemInfoSendThisAsEmail }) 
function CmsSystemInfoSendThisAsEmail { 
$FormCmsSystemInfoSendThisAsEmail = New-Object System.Windows.Forms.Form
$FormCmsSystemInfoSendThisAsEmail.Text = "E-Mail Startup-Information" 
$FormCmsSystemInfoSendThisAsEmail.StartPosition = "CenterScreen"
$FormCmsSystemInfoSendThisAsEmail.Topmost = $false 
$FormCmsSystemInfoSendThisAsEmail.Size = "350,100"
$FormCmsSystemInfoSendThisAsEmail.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : Username
$FormCmsSystemInfoSendThisAsEmailLabelUsername = New-object System.Windows.Forms.Label   
$FormCmsSystemInfoSendThisAsEmailLabelUsername.location = "90,5" 
$FormCmsSystemInfoSendThisAsEmailLabelUsername.size = "250,20"
$FormCmsSystemInfoSendThisAsEmailLabelUsername.text = "Username"
$FormCmsSystemInfoSendThisAsEmail.Controls.Add($FormCmsSystemInfoSendThisAsEmailLabelUsername)
# Textbar Username
$CmsSystemInfoSendThisAsEmailTextbarUsername = New-object System.Windows.Forms.Textbox   
$CmsSystemInfoSendThisAsEmailTextbarUsername.location = "5,30" 
$CmsSystemInfoSendThisAsEmailTextbarUsername.size = "250,20"
$FormCmsSystemInfoSendThisAsEmail.Controls.Add($CmsSystemInfoSendThisAsEmailTextbarUsername)
# Send Button
$FormCmsSystemInfoSendThisAsEmailButtonSend = New-object System.Windows.Forms.Button 
$FormCmsSystemInfoSendThisAsEmailButtonSend.text= "Send E-Mail"   
$FormCmsSystemInfoSendThisAsEmailButtonSend.location = "265,30" 
$FormCmsSystemInfoSendThisAsEmailButtonSend.size = $ValueButtonSize  
$FormCmsSystemInfoSendThisAsEmailButtonSend.Add_Click({ FormCmsSystemInfoSendThisAsEmail }) 
$FormCmsSystemInfoSendThisAsEmail.Controls.Add($FormCmsSystemInfoSendThisAsEmailButtonSend)
function FormCmsSystemInfoSendThisAsEmail { 
$SmtpServer = $SmtpAdressToMailServer 
$SmtpUser = $ApplicationFormServiceUserId
$smtpPassword = $ApplicationFormServiceUserPassword
$SmtpUsername = $CmsSystemInfoSendThisAsEmailTextbarUsername.text
$SmtpUsernameDomain = $SmtpFqdn
$MailtTo = $SmtpUsername + $SmtpUsernameDomain
$MailFrom = $ApplicationFormServiceUserId
$TextbarData = $ApplicationFormTextBarSearchBar.text

$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++

$ApplicationFormStatusBarStatusPanel.Text =  "Sending System-information to user $MailtTo, Wait"
$MailSubject = "System-information  on $TextbarData"

$MailBodyGetsysComp = Get-WmiObject Win32_ComputerSystem -ComputerName $TextbarData -ErrorVariable SysError  | out-string -Width 8192
$MailBodyGetsysComp2 = Get-WmiObject Win32_ComputerSystemProduct -ComputerName $TextbarData  | out-string -Width 8192
$MailBodyGetsysOS = Get-WmiObject Win32_OperatingSystem -ComputerName $TextbarData  | out-string -Width 8192
$MailBodyGetsysBIOS = Get-WmiObject Win32_BIOS -ComputerName $TextbarData  | out-string -Width 8192
$MailBodyGetsysCPU = Get-WmiObject Win32_Processor -ComputerName $TextbarData | Sort Name | format-list Name, Manufacturer, Description, DeviceID, L2CacheSize, L3CacheSize, NumberOfCores, NumberOfLogicalProcessors, SocketDesignation, Status | out-string -Width 8192
$MailBodyGetsysRAM = Get-WmiObject Win32_PhysicalMemory -ComputerName $TextbarData | Sort Manufacturer | format-list Manufacturer, Name, SerialNumber, Description, DeviceLocator, Speed, Status, TotalWidth, TypeDetail | out-string -Width 8192
$MailBodyGetsysNAC = Get-WmiObject Win32_NetworkAdapterConfiguration -ComputerName $TextbarData -Filter "IPEnabled='True'" | Sort Name | format-list Description, IPAddress, DefaultIPGateway, DNSDomain, DHCPEnabled, ServiceName| out-string -Width 8192
$MailBodyGetsysMon = Get-WmiObject Win32_DesktopMonitor -ComputerName $TextbarData | Sort Name | format-list DeviceID, Description, MonitorManufacturer, PNPDeviceID, PixelsPerXLogicalInch, PixelsPerYLogicalInch, ScreenHeight, ScreenWidth, Status, SystemCreationClassName | out-string -Width 8192
$MailBodyGetsysVid = Get-WmiObject Win32_VideoController -ComputerName $TextbarData | sort name | format-list Name, Videoprocessor, VideoModeDescription, Status, MinRefreshRate, MaxRefreshRate, InstalledDisplayDrivers, InfSection, InfFilename, CurrentBitsPerPixel, CurrentHorizontalResolution, CurrentNumberOfColors, CurrentNumberOfColumns, CurrentNumberOfRows, CurrentRefreshRate, CurrentScanMode, CurrentVerticalResolution | out-string -Width 8192
$MailBodyGetsysOD = Get-WmiObject Win32_CDROMDrive -ComputerName $TextbarData  | Sort Drive | format-list Caption, Drive, Manufacturer, VolumeName | out-string -Width 8192
$MailBodyGetsysHD = Get-WmiObject Win32_LogicalDisk -ComputerName $TextbarData | Sort DeviceID | format-list DeviceID, VolumeName, Size, FreeSpace, DriveType   | out-string -Width 8192
$MailBodyGetsysProc = Get-WmiObject Win32_Process -ComputerName $TextbarData | Sort ProcessName | format-list ProcessName, ProcessId, ExecutablePath, SessionId, Path | out-string -Width 8192

$MailBody = "System-information On $TextbarData $MailBodyGetsysComp $MailBodyGetsysComp2 $MailBodyGetsysOS $MailBodyGetsysBIOS $MailBodyGetsysCPU $MailBodyGetsysRAM $MailBodyGetsysNAC $MailBodyGetsysMon $MailBodyGetsysVid  $MailBodyGetsysOD $MailBodyGetsysHD $MailBodyGetsysProc"

$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $SmtpUser, $($smtpPassword | ConvertTo-SecureString -AsPlainText -Force) 
Send-MailMessage -To "$MailtTo" -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8) -UseSsl -Credential $Credentials

$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

$FormCmsSystemInfoSendThisAsEmail.Close()}

###################
# Initlize FormCmsStartupSendThisAsEmail
$FormCmsSystemInfoSendThisAsEmail.Add_Shown({$FormCmsSystemInfoSendThisAsEmail.Activate()})
[void] $FormCmsSystemInfoSendThisAsEmail.ShowDialog()}
[void]$ContextMenu.Items.Add($CmsSystemInfoSendThisAsEmail)


#------------------------------------------------------------------------------------#
######################################################################################
######################################################################################
######################################################################################
#------------------------------------------------------------------------------------#

######################################################################################
                      # AutoLoad Modules #
######################################################################################

######################################################################################
# Autoload Modules #
Import-Module ActiveDirectory
#-------------------------------------------------------------------------------------#

#------------------------------------------------------------------------------------#
######################################################################################
######################################################################################
######################################################################################
#------------------------------------------------------------------------------------#



######################################################################################
                                 # Main Form #
######################################################################################

######################################################################################
#
#  Progressbar
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
# Progressbar
$ApplicationFormProgressBar = New-Object System.Windows.Forms.ProgressBar
$ApplicationFormProgressBar.Location = "620,55"
$ApplicationFormProgressBar.Size = "150,20"
$ApplicationForm.Controls.Add($ApplicationFormProgressBar)

######################################################################################
# StatusBar Side StatusText Progressbar
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormStatusBar = New-Object System.Windows.Forms.StatusBar
$ApplicationFormStatusBar.Anchor = 'Bottom, Left, Right'
$ApplicationFormStatusBar.Dock = 'None'
$ApplicationFormStatusBar.Location = '215,55'
$ApplicationFormStatusBar.Name = "StatusBar"
$ApplicationFormStatusBar.ShowPanels = $True
$ApplicationFormStatusBar.Size = '400, 20'
$ApplicationFormStatusBar.Text = "Ready"
$ApplicationForm.Controls.Add($ApplicationFormStatusBar)

######################################################################################
# # StatusbarPanel
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormStatusBarStatusPanel = New-Object System.Windows.Forms.StatusbarPanel
$ApplicationFormStatusBarStatusPanel.AutoSize = 'Spring'
$ApplicationFormStatusBarStatusPanel.Name = "ApplicationFormStatusBarStatusPanel"
$ApplicationFormStatusBarStatusPanel.Text = "Ready"
$ApplicationFormStatusBarStatusPanel.Width = 620
[void]$ApplicationFormStatusBar.Panels.Add($ApplicationFormStatusBarStatusPanel)

######################################################################################
# # Search Label
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormTextBarSearchLabel = New-Object System.Windows.Forms.Label
$ApplicationFormTextBarSearchLabel.Location = "25,40" 
$ApplicationFormTextBarSearchLabel.Size = "155,15" 
$ApplicationFormTextBarSearchLabel.Text = "Type Username/Hostname/Ip" 
$ApplicationForm.Controls.Add($ApplicationFormTextBarSearchLabel)

######################################################################################
# SearchBar
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormTextBarSearchBar = New-Object System.Windows.Forms.Textbox
$ApplicationFormTextBarSearchBar.Location = "25,55" 
$ApplicationFormTextBarSearchBar.Size = "150,50"
$ApplicationForm.Controls.Add($ApplicationFormTextBarSearchBar)


######################################################################################
# TopBar Menu MenuStrip
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormMenuStrip = New-Object System.Windows.Forms.MenuStrip
$ApplicationFormMenuStrip.Location = '0, 0'
$ApplicationFormMenuStrip.Name = "MainMenu"
$ApplicationFormMenuStrip.Size = '780, 24'
$ApplicationFormMenuStrip.Text = "Main"
$ApplicationForm.Controls.Add($ApplicationFormMenuStrip)

######################################################################################
# TopBar Menu MenuStrip, Sub Menu, File
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormMenuStripFile = New-Object System.Windows.Forms.ToolStripMenuItem
$ApplicationFormMenuStripFile.Name = "MenuFile"
$ApplicationFormMenuStripFile.Size = '37, 20'
$ApplicationFormMenuStripFile.Text = "File"
[void]$ApplicationFormMenuStrip.Items.Add($ApplicationFormMenuStripFile)
######################################################################################
# TopBar Menu MenuStrip, Sub Menu, File, Exit
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormMenuStripFileExit = New-Object System.Windows.Forms.ToolStripMenuItem
$ApplicationFormMenuStripFileExit.Name = "MenuFileExit"
$ApplicationFormMenuStripFileExit.Size = '186, 22'
$ApplicationFormMenuStripFileExit.Text = "Exit"
$ApplicationFormMenuStripFileExit.Add_Click({$ApplicationForm.Close()}) 
[void]$ApplicationFormMenuStripFile.DropDownItems.Add($ApplicationFormMenuStripFileExit)

######################################################################################
# TopBar Menu MenuStrip, Sub Menu, View
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormMenuStripView = New-Object System.Windows.Forms.ToolStripMenuItem
$ApplicationFormMenuStripView.Name = "MenuView"
$ApplicationFormMenuStripView.Size = '37, 20'
$ApplicationFormMenuStripView.Text = "View"
[void]$ApplicationFormMenuStrip.Items.Add($ApplicationFormMenuStripView)

######################################################################################
# TopBar Menu MenuStrip, Sub Menu, View, C-Harddrive Menu
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormMenuStripViewCdisk = New-Object System.Windows.Forms.ToolStripMenuItem
$ApplicationFormMenuStripViewCdisk.Name = "CDisk"
$ApplicationFormMenuStripViewCdisk.Size = '186, 22'
$ApplicationFormMenuStripViewCdisk.Text = "C-HardDrive"
$ApplicationFormMenuStripViewCdisk.Add_Click({ ViewCDiskOnWorkstation })   
function ViewCDiskOnWorkstation { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$ApplicationFormProgressBar.Value ++
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Starting File-explorer On $TextbarData"
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
Explorer.exe \\$TextbarData\c$ 
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
 }}
[void]$ApplicationFormMenuStripView.DropDownItems.Add($ApplicationFormMenuStripViewCdisk)


######################################################################################
# TopBar Menu MenuStrip, Sub Menu, View, EventViewer Menu
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormMenuStripViewEventViewer = New-Object System.Windows.Forms.ToolStripMenuItem
$ApplicationFormMenuStripViewEventViewer.Name = "EventViewer"
$ApplicationFormMenuStripViewEventViewer.Size = '186, 22'
$ApplicationFormMenuStripViewEventViewer.Text = "EventViewer"
$ApplicationFormMenuStripViewEventViewer.Add_Click({ ViewEventViewerOnWorkstation })   
function ViewEventViewerOnWorkstation { # function to remote open and see c:\
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$ApplicationFormProgressBar.Value ++
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
$ApplicationFormStatusBarStatusPanel.text = "Ping successful, Starting EventViewer on $TextbarData"
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
EventVwr $TextbarData
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
 }}
[void]$ApplicationFormMenuStripView.DropDownItems.Add($ApplicationFormMenuStripViewEventViewer)


######################################################################################
# TopBar Menu MenuStrip, ViewMenum, ServiceMenu, 
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormMenuStripViewServiceMsc = New-Object System.Windows.Forms.ToolStripMenuItem
$ApplicationFormMenuStripViewServiceMsc.Name = "ServiceMscMenu"
$ApplicationFormMenuStripViewServiceMsc.Size = '186, 22'
$ApplicationFormMenuStripViewServiceMsc.Text = "Services"
$ApplicationFormMenuStripViewServiceMsc.Add_Click({ ViewServicesOnWorkstation })   
function ViewServicesOnWorkstation { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
start-sleep -m  100
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Starting Service.Msc On $TextbarData"
Services.msc /Computer=$TextbarData
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormStatusBarStatusPanel.text = "Task Completed, It will take some seconds to load Services.msc"
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
}}
[void]$ApplicationFormMenuStripView.DropDownItems.Add($ApplicationFormMenuStripViewServiceMsc)

######################################################################################
# TopBar Menu MenuStrip, ViewMenum, ServiceMenu, User And Groups
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormMenuStripViewUserAndGroups = New-Object System.Windows.Forms.ToolStripMenuItem
$ApplicationFormMenuStripViewUserAndGroups.Name = "UserAndGroupsMsc"
$ApplicationFormMenuStripViewUserAndGroups.Size = '186, 22'
$ApplicationFormMenuStripViewUserAndGroups.Text = "User And Groups"
$ApplicationFormMenuStripViewUserAndGroups.Add_Click({ ViewUSerAndGroupsOnWorkstation })   
function ViewUSerAndGroupsOnWorkstation { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  250
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Starting LUsrMgr.Msc On $TextbarData"
LUsrMgr.msc /Computer=$TextbarData
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  100 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
 }}
[void]$ApplicationFormMenuStripView.DropDownItems.Add($ApplicationFormMenuStripViewUserAndGroups)

######################################################################################
# TopBar Menu MenuStrip, Menu Help
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormMenuStripHelp = New-Object System.Windows.Forms.ToolStripMenuItem
$ApplicationFormMenuStripHelp.Name = "MenuHelp"
$ApplicationFormMenuStripHelp.Size = '37, 20'
$ApplicationFormMenuStripHelp.Text = "Help"
[void]$ApplicationFormMenuStrip.Items.Add($ApplicationFormMenuStripHelp)

######################################################################################
# TopBar Menu MenuStrip, Menu Help, QuickHelp HelpDesk QUickfix
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$ApplicationFormMenuStripHelpQuickHelp = New-Object System.Windows.Forms.ToolStripMenuItem
$ApplicationFormMenuStripHelpQuickHelp.Name = "QuickHelp"
$ApplicationFormMenuStripHelpQuickHelp.Size = '186, 22'
$ApplicationFormMenuStripHelpQuickHelp.Text = "Quick Help"
$ApplicationFormMenuStripHelpQuickHelp.Add_Click({ OpenFileQuickHelp })   
function OpenFileQuickHelp { start-process $HelpFileLocation }
[void]$ApplicationFormMenuStripHelp.DropDownItems.Add($ApplicationFormMenuStripHelpQuickHelp)

#-------------------------------------------------------------------------------------#

######################################################################################
############################# T A B S ################################################
######################################################################################

######################################################################################
# MainTab - Tabcontrol
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$FormTabControl = New-object System.Windows.Forms.TabControl 
$FormTabControl.Size = "755,475" 
$FormTabControl.Location = "25,75" 
$ApplicationForm.Controls.Add($FormTabControl)
#-------------------------------------------------------------------------------------#

######################################################################################
# MainTab - Tabcontrol - Computer Tab
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$TabComputer = New-object System.Windows.Forms.Tabpage
$TabComputer.DataBindings.DefaultDataSourceUpdateMode = 0 
$TabComputer.UseVisualStyleBackColor = $True 
$TabComputer.Name = "TabComputer" 
$TabComputer.Text = "Local Computer” 
$FormTabControl.Controls.Add($TabComputer)

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Listview 
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$lvMain = New-Object System.Windows.Forms.ListView
$lvmain.Scrollable = $true 
$lvMain.ContextMenuStrip = $ContextMenu
$lvMain.FullRowSelect = $True
$lvMain.GridLines = $True
$lvMain.Location = "5, 21"
$lvMain.Name = "lvMain"
$lvMain.Size = "650, 418"
$lvMain.TabIndex = "13"
$lvMain.UseCompatibleStateImageBehavior = $False
$lvMain.View = "Details"
$TabComputer.Controls.Add($lvMain) 

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Label :  Admin Tools 
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$TabComputerLabelAdminTools = New-object System.Windows.Forms.Label
$TabComputerLabelAdminTools.text = "Admin-Tools"
$TabComputerLabelAdminTools.location = "679,5" 
$TabComputerLabelAdminTools.size = "200,15" 
$TabComputer.Controls.Add($TabComputerLabelAdminTools)
#-----------------------------------------------------------------------------------#


######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 1 : App-Info
# Downloads a list of installed apps that is installed on the workstation
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$TabComputerBtnApplicationsInfo = New-object System.Windows.Forms.Button 
$TabComputerBtnApplicationsInfo.text= "App-Info"   
$TabComputerBtnApplicationsInfo.location = "670,20" 
$TabComputerBtnApplicationsInfo.size = $ValueButtonSize  
$TabComputerBtnApplicationsInfo.Add_Click({ RetriveInstalledAppsOnWorkstation }) 
$TabComputer.Controls.Add($TabComputerBtnApplicationsInfo) 
function RetriveInstalledAppsOnWorkstation { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
If ($PingRequest -eq $true) {
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Ping Successful, Generate Installed-App-List From $TextbarData, ETA 10 Sec"
$ApplicationFormProgressBar.Value ++
Initialize-Listview
Update-ContextMenu (Get-Variable CmsApp*)
$XML.Options.Applications.Property | %{Add-Column $_}
Resize-Columns
$Col0 = $lvMain.Columns[0].Text
$Info = Get-WmiObject win32_Product -ComputerName $TextbarData -ErrorVariable SysError | Sort Name,Vendor
start-sleep -m  100
if($SysError){$ApplicationFormStatusBarStatusPanel.Text = "[$TextbarData] $SysError"}
else{
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
$ApplicationFormProgressBar.Value ++
$Info | %{
$Item = New-Object System.Windows.Forms.ListViewItem($_.$Col0)
ForEach ($Col in ($lvMain.Columns | ?{$_.Index -ne 0})){$Field = $Col.Text;$Item.SubItems.Add($_.$Field)}
$lvMain.Items.Add($Item)
start-sleep -m  10
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

}}
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
 }}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 2 : Auto-Logon
# Creates a Auto-Logon, when the computers boots, it will automatic login with
# created credentials
#------------------------------------------------------------------------------------#
$TabComputerBtnAutoLogon = New-object System.Windows.Forms.Button 
$TabComputerBtnAutoLogon.text= "Auto-Logon"   
$TabComputerBtnAutoLogon.location = "670,41" 
$TabComputerBtnAutoLogon.size = $ValueButtonSize  
$TabComputerBtnAutoLogon.Add_Click({ GenerateFormAutoLogon }) 
$TabComputer.Controls.Add($TabComputerBtnAutoLogon)
Function GenerateFormAutoLogon {
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  75 
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Creating AutoLogon Form"
start-sleep -m  75
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
$ApplicationFormProgressBar.Value ++
start-sleep -m  75
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready" 
#Generated Form  
$FormAutoLogon = New-Object System.Windows.Forms.Form
$FormAutoLogon.Text = "Create Automatic Login On $TextbarData" 
$FormAutoLogon.StartPosition = "CenterScreen"
$FormAutoLogon.Topmost = $false 
$FormAutoLogon.Size = "290,150"
$FormAutoLogon.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")  

#Textbar UserLogin
$FormAutoLogonTextBarLogin = New-Object System.Windows.Forms.Textbox
$FormAutoLogonTextBarLogin.text = "Enter Username"  
$FormAutoLogonTextBarLogin.location ="5,5"
$FormAutoLogonTextBarLogin.size = "260,20"
$FormAutoLogon.Controls.Add($FormAutoLogonTextBarLogin) 
$FormAutoLogonUsername = $FormAutoLogonTextBarLogin.text

#Textbar UserPassword
$FormAutoLogonTextBarPassWord = New-Object System.Windows.Forms.Textbox
$FormAutoLogonTextBarPassWord.text = "Enter Password"  
$FormAutoLogonTextBarPassWord.location ="5,30"
$FormAutoLogonTextBarPassWord.size = "260,20"
$FormAutoLogon.Controls.Add($FormAutoLogonTextBarPassWord) 
$FormAutoLogonPassWord = $FormAutoLogonTextBarPassWord.text

#CheckBox If its a domain-joined workstation
$FormAutoLogonCheckDomainComputer = New-Object System.Windows.Forms.checkbox
$FormAutoLogonCheckDomainComputer.text = "Computer have joined Domain, $FormAutoLogonCheckDomainName"
$FormAutoLogonCheckDomainComputer.location ="5,70"
$FormAutoLogonCheckDomainComputer.size = "280,20"
$FormAutoLogonCheckDomainComputer.checked = $true
$FormAutoLogon.Controls.Add($FormAutoLogonCheckDomainComputer) 
$FormAutoLogonDefaultDomainName = "xxx.xxx"


#Button Create Auto-Login
$FormAutoLogonBtnCreateAutoLogin = New-Object System.Windows.Forms.button
$FormAutoLogonBtnCreateAutoLogin.text = "Create Auto-Login"  
$FormAutoLogonBtnCreateAutoLogin.location ="5,95"
$FormAutoLogonBtnCreateAutoLogin.size = "120,20"
$FormAutoLogonBtnCreateAutoLogin.Add_Click({ CreateAutoLoginOnWorkstation }) 
$FormAutoLogon.Controls.Add($FormAutoLogonBtnCreateAutoLogin) 
Function CreateAutoLoginOnWorkstation {
$TextbarData = $ApplicationFormTextBarSearchBar.Text 
$FormAutoLogon.Close()
}

#Button Disable Auto-Login
$FormAutoLogonBtnDisableAutoLogin = New-Object System.Windows.Forms.button
$FormAutoLogonBtnDisableAutoLogin.text = "Disable Auto-Login"  
$FormAutoLogonBtnDisableAutoLogin.location ="140,95"
$FormAutoLogonBtnDisableAutoLogin.size = "120,20"
$FormAutoLogonBtnDisableAutoLogin.Add_Click({ DisableAutoLoginOnWorkstation }) 
$FormAutoLogon.Controls.Add($FormAutoLogonBtnDisableAutoLogin) 
Function DisableAutoLoginOnWorkstation {
$TextbarData = $ApplicationFormTextBarSearchBar.Text 
$FormAutoLogon.Close()
}

# Initlize the Form
$FormAutoLogon.Add_Shown({$FormAutoLogon.Activate()})
[void] $FormAutoLogon.ShowDialog()

} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
 }}


######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 3 : Clean Pc
# Functions Remove the content in ccm-cache and temp folder.
#------------------------------------------------------------------------------------#
$TabComputerBtnCleanPc = New-object System.Windows.Forms.Button 
$TabComputerBtnCleanPc.text= "Clean Pc"   
$TabComputerBtnCleanPc.location = "670,62" 
$TabComputerBtnCleanPc.size = $ValueButtonSize  
$TabComputerBtnCleanPc.Add_Click({ GenerateFormCleanPc }) 
$TabComputer.Controls.Add($TabComputerBtnCleanPc) 
function GenerateFormCleanPc { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Creating Clean-Pc Form"
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m  50
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
#Generated Form  
$FormCleanPc = New-Object System.Windows.Forms.Form
$FormCleanPc.Text = "Remove Files On $TextbarData" 
$FormCleanPc.StartPosition = "CenterScreen"
$FormCleanPc.Topmost = $false 
$FormCleanPc.Size = "250,125"
$FormCleanPc.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
#Button Delete Ccm
$FormCleanPcDeleteButton = New-Object System.Windows.Forms.button
$FormCleanPcDeleteButton.text = "Delete Ccm"  
$FormCleanPcDeleteButton.location ="75,20"
$FormCleanPcDeleteButton.size = "80,20"
$FormCleanPcDeleteButton.Add_Click({ DeleteCcmContent }) 
$FormCleanPc.Controls.Add($FormCleanPcDeleteButton) 
Function DeleteCcmContent { 
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
$PathCcmCache = "c$\Windows\ccmcache\*"
$UncCcm = "\\$TextbarData\$PathCcmCache"
$ApplicationFormStatusBarStatusPanel.text = "Ping successful, Starting Process to remove the content in CCM-Cache"
$ApplicationFormProgressBar.Value ++
Remove-Item $UncCcm -Force
start-sleep -m  50
$ApplicationFormStatusBarStatusPanel.text = "Removing Content"
start-sleep -m  50
$ApplicationFormStatusBarStatusPanel.text = "Task Completed, you maby need to press Y in the background-popup-box"
start-sleep -m  50
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
$ApplicationFormProgressBar.Value = 0;
} else {
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;}}
#Button Delete Temp
$FormCleanPcDeleteButton = New-Object System.Windows.Forms.button
$FormCleanPcDeleteButton.text = "Delete Temp"  
$FormCleanPcDeleteButton.location ="76,50"
$FormCleanPcDeleteButton.size = "80,20"
$FormCleanPcDeleteButton.Add_Click({ DeleteTempContent }) 
$FormCleanPc.Controls.Add($FormCleanPcDeleteButton) 
Function DeleteTempContent {
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
If ($PingRequest -eq $true) { 
start-sleep -m  50
$PathTempFolder = "c$\Windows\Temp\*"
$UncTemp = "\\$TextbarData\$PathTempFolder"
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.text = "Ping successful, Starting Process to remove the content in Temp Folder"
Remove-Item $UncTemp -Force
start-sleep -m  50
$ApplicationFormStatusBarStatusPanel.text = "Removing Content"
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
$ApplicationFormStatusBarStatusPanel.text = "Task Completed, you maby need to press Y in the background-popup-box"
start-sleep -m  50
$ApplicationFormStatusBarStatusPanel.text = "Task Completed, Ready"
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
$ApplicationFormProgressBar.Value = 0;
} else {
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;}}
# Initlize the Form
$FormCleanPc.Add_Shown({$FormCleanPc.Activate()})
[void] $FormCleanPc.ShowDialog()
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
}}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 4 : Cmd Tasks
# Various Cmd-Task as gpo update etc.
#------------------------------------------------------------------------------------#
$TabComputerBtnCmdCommands = New-object System.Windows.Forms.Button 
$TabComputerBtnCmdCommands.text= "Cmd-Tasks"   
$TabComputerBtnCmdCommands.location = "670,83" 
$TabComputerBtnCmdCommands.size = $ValueButtonSize  
$TabComputerBtnCmdCommands.Add_Click({ GenerateFormCmdCommands }) 
$TabComputer.Controls.Add($TabComputerBtnCmdCommands) 
function GenerateFormCmdCommands { 
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Creating Cmd-Commands Form"
start-sleep -m  50
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
$ApplicationFormStatusBarStatusPanel.text = "Task Completed. Cmd-Form Created"
start-sleep -m  50
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
### Generated Form  
$FormCmdCommands = New-Object System.Windows.Forms.Form
$FormCmdCommands.Text = "Execute Cmd-Commands On $TextbarData" 
$FormCmdCommands.StartPosition = "CenterScreen"
$FormCmdCommands.Topmost = $false 
$FormCmdCommands.Size = "250,350"
$FormCmdCommands.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
#---------------#
# checkbox - Gpupdate  
$FormCmdCheckboxUpdateGpo = New-Object System.Windows.Forms.checkbox
$FormCmdCheckboxUpdateGpo.text = "Update Gpo"  
$FormCmdCheckboxUpdateGpo.location ="5,5"
$FormCmdCheckboxUpdateGpo.size = "100,20"
$FormCmdCheckboxUpdateGpo.Add_Click({ CmdCommandUpdateGpo}) 
$FormCmdCommands.Controls.Add($FormCmdCheckboxUpdateGpo) 
function CmdCommandUpdateGpo {}
#---------------#
#checkbox - Gpupdate / force 
$FormCmdCheckboxUpdateGpoForce = New-Object System.Windows.Forms.checkbox
$FormCmdCheckboxUpdateGpoForce.text = "Update Gpo /F"    
$FormCmdCheckboxUpdateGpoForce.location ="110,5"
$FormCmdCheckboxUpdateGpoForce.size = "100,20"
$FormCmdCheckboxUpdateGpoForce.Add_Click({ CmdCommandUpdateGpoForce}) 
$FormCmdCommands.Controls.Add($FormCmdCheckboxUpdateGpoForce) 
function CmdCommandUpdateGpoForce { }
#---------------#
#checkbox ( IPconfig /FlushDns ), Ipconfig Renew Ip  ( IPconfig /Renew Ip  ), Ipconfig Release Ip  ( IPconfig /Release Ip  ),#checkbox shutdown -s ,#checkbox  shutdown -r ,#checkbox  shutdown -a



#---------------#
#Button Run Command 
$FormCmdBtnRunCommand = New-Object System.Windows.Forms.button
$FormCmdBtnRunCommand.text = "Run Command"    
$FormCmdBtnRunCommand.location ="75,290"
$FormCmdBtnRunCommand.size = "100,20"
$FormCmdBtnRunCommand.Add_Click({ CmdBtnRunCommand}) 
$FormCmdCommands.Controls.Add($FormCmdBtnRunCommand) 
function CmdBtnRunCommand {
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Sending Command "

start-sleep -m  50
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "ExeCo,mand "
start-sleep -m  50
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$ApplicationFormProgressBar.Value = 0;
$FormCmdCommands.Close()
} else {
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;}}

$ApplicationFormStatusBarStatusPanel.text = "Ready"
$ApplicationFormProgressBar.Value = 0;
# Initlize the Form
$FormCmdCommands.Add_Shown({$FormCmdCommands.Activate()})
[void] $FormCmdCommands.ShowDialog()

} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
}}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 5 : Dameware
# Opens the installed remote app Dameware on the DC
#------------------------------------------------------------------------------------#
$TabComputerBtnDameWare = New-object System.Windows.Forms.Button 
$TabComputerBtnDameWare.text = "Dameware"   
$TabComputerBtnDameWare.location = "670,104" 
$TabComputerBtnDameWare.size = $ValueButtonSize 
$TabComputerBtnDameWare.Add_Click({ OpenDameware }) 
$TabComputer.Controls.Add($TabComputerBtnDameWare)  
function OpenDameware { 
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Starting Dameware Remote"
start-sleep -m  50
Start-Process $ApplicationDamewarePath

$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"

$ApplicationFormProgressBar.Value ++
start-sleep -m 50
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
}}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 6 : DC-Dix-W7
# Repairs the secure channel between the local computer and its domain
# Works only with w7
#------------------------------------------------------------------------------------#
$TabComputerBtnDomainFix = New-object System.Windows.Forms.Button 
$TabComputerBtnDomainFix.text= "DC-Fix-W7"   
$TabComputerBtnDomainFix.location = "670,125" 
$TabComputerBtnDomainFix.size = $ValueButtonSize  
$TabComputerBtnDomainFix.Add_Click({ DomainFixRelationship }) 
$TabComputer.Controls.Add($TabComputerBtnDomainFix) 
function DomainFixRelationship { 
$TextbarData = $ApplicationFormTextBarSearchBar.text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  50
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Starting Process To Fix the Kerberos Error"
start-sleep -m  50
$InvokeCommandAddW7ComputerToDomain = Invoke-Command -Computer $TextbarData -ScriptBlock { }
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
$ApplicationFormProgressBar.Value ++
start-sleep -m 50
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
}}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 7 : Local Adm
# Creates a local admin on the PC, emails the password and userid, to the user.
# 
#------------------------------------------------------------------------------------#
$TabComputerBtnCreateLocalAdmin = New-object System.Windows.Forms.Button 
$TabComputerBtnCreateLocalAdmin.text= "Local-Adm"   
$TabComputerBtnCreateLocalAdmin.location = "670,146" 
$TabComputerBtnCreateLocalAdmin.size = $ValueButtonSize  
$TabComputerBtnCreateLocalAdmin.Add_Click({ GenerateLocalAdminForm }) 
$TabComputer.Controls.Add($TabComputerBtnCreateLocalAdmin) 
Function GenerateLocalAdminForm {
TextConfirmationData
$FormLocalAdmin = New-Object System.Windows.Forms.Form
$FormLocalAdmin.Text = "Create a Local Admin"
$FormLocalAdmin.Topmost = $false 
$FormLocalAdmin.Size = "300,500"
$FormLocalAdmin.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label Title Connect to
$FormLocalAdminLabelConnectTo = New-object System.Windows.Forms.Label
$FormLocalAdminLabelConnectTo.location = "5,25"
$FormLocalAdminLabelConnectTo.text = " - Connect to - " 
$FormLocalAdminLabelConnectTo.size = "140,15 " 
$FormLocalAdmin.Controls.Add($FormLocalAdminLabelConnectTo) 
# Label Ip Adress
$FormLocalAdminLabelIpadress = New-object System.Windows.Forms.Label
$FormLocalAdminLabelIpadress.location = "5,50" 
$FormLocalAdminLabelIpadress.text = "Ip-adress"
$FormLocalAdminLabelIpadress.size = "75,15"
$FormLocalAdmin.Controls.Add($FormLocalAdminLabelIpadress)
# Textbox Ipadress
$FormLocalAdminFieldTextBoxIpadress = New-object System.Windows.Forms.Textbox
$FormLocalAdminFieldTextBoxIpadress.location = "5,65"  
$FormLocalAdminFieldTextBoxIpadress.text = "172.18" 
$FormLocalAdminFieldTextBoxIpadress.size = "250,15"  
$FormLocalAdmin.Controls.Add($FormLocalAdminFieldTextBoxIpadress) 
# Label LocalCredentials,LocalUsername  Text = "- Local Credentials To Be Created -" 
$FormLocalAdminLabelLocalCredentials = New-object System.Windows.Forms.Label
$FormLocalAdminLabelLocalCredentials.location = "5,125"
$FormLocalAdminLabelLocalCredentials.text = "- Local Credentials -" 
$FormLocalAdminLabelLocalCredentials.size = "140,15" 
$FormLocalAdmin.Controls.Add($FormLocalAdminLabelLocalCredentials)
# Label LocalCredentials,LocalUsername  Text = "  Local Username "
$FormLocalAdminLabelLocalUsername = New-object System.Windows.Forms.Label
$FormLocalAdminLabelLocalUsername.location = "5,150" 
$FormLocalAdminLabelLocalUsername.text = "Username"
$FormLocalAdminLabelLocalUsername.size = "125,15"
$FormLocalAdmin.Controls.Add($FormLocalAdminLabelLocalUsername)
# Textbox Local Username that will be created on the pc
$FormLocalAdminFieldTextBoxLocalUsername = New-object System.Windows.Forms.Textbox
$FormLocalAdminFieldTextBoxLocalUsername.location = "5,170"
$FormLocalAdminFieldTextBoxLocalUsername.text = $FormLocalAdminFieldTextBoxLocalUsernametext
$FormLocalAdminFieldTextBoxLocalUsername.size = "250,15" 
$FormLocalAdmin.Controls.Add($FormLocalAdminFieldTextBoxLocalUsername) 
# Label LocalCredentials,LocalPassword  Text = " - Local Password " 
$FormLocalAdminLabelLocalPassword = New-object System.Windows.Forms.Label
$FormLocalAdminLabelLocalPassword.location = "5,200"
$FormLocalAdminLabelLocalPassword.text = "Password"
$FormLocalAdminLabelLocalPassword.size = "125,15"
$FormLocalAdmin.Controls.Add($FormLocalAdminLabelLocalPassword)
# FieldTextbox Local Password that will be created on the pc 
$FormLocalAdminFieldTextBoxLocalPassword = New-object System.Windows.Forms.Textbox
$FormLocalAdminFieldTextBoxLocalPassword.location = "5,215" 
$FormLocalAdminFieldTextBoxLocalPassword.text = $FormLocalAdminFieldTextBoxLocalPasswordtext
$FormLocalAdminFieldTextBoxLocalPassword.size = "250,15" 
$FormLocalAdmin.Controls.Add($FormLocalAdminFieldTextBoxLocalPassword) 
# Label Active Directory Fields
$FormLocalAdminLabelActiveDirectoryFields = New-object System.Windows.Forms.Label
$FormLocalAdminLabelActiveDirectoryFields.location = "5,275" 
$FormLocalAdminLabelActiveDirectoryFields.text = "- Active Directory, Fields -"
$FormLocalAdminLabelActiveDirectoryFields.size = "140,15"
$FormLocalAdmin.Controls.Add($FormLocalAdminLabelActiveDirectoryFields)
# Label Active Directory Fields, Ad Username, Text = " Ad-Account "
$FormLocalAdminLabelAdAccountUserName = New-object System.Windows.Forms.Label
$FormLocalAdminLabelAdAccountUserName.location = "5,300" 
$FormLocalAdminLabelAdAccountUserName.text = "Username" 
$FormLocalAdminLabelAdAccountUserName.size = "125,15" 
$FormLocalAdmin.Controls.Add($FormLocalAdminLabelAdAccountUserName)  
# Textbox,Active Directory Fields, Ad username
$FormLocalAdminFieldTextBoxAdAccountUserName = New-object System.Windows.Forms.Textbox
$FormLocalAdminFieldTextBoxAdAccountUserName.text = "" 
$FormLocalAdminFieldTextBoxAdAccountUserName.location = "5,315" 
$FormLocalAdminFieldTextBoxAdAccountUserName.size = "250,15" 
$FormLocalAdmin.Controls.Add($FormLocalAdminFieldTextBoxAdAccountUserName) 
# Label "Active Directory Fields, Pc Number, Text = " Pc-Number "
$FormLocalAdminLabelPcNumber = New-object System.Windows.Forms.Label
$FormLocalAdminLabelPcNumber.location = "5,350"
$FormLocalAdminLabelPcNumber.size = "100,15 " 
$FormLocalAdminLabelPcNumber.text = "Pc-Number"   
$FormLocalAdmin.Controls.Add($FormLocalAdminLabelPcNumber) 
# FieldTextbox PC textbox
$FormLocalAdminFieldTextBoxPcnumber = New-object System.Windows.Forms.Textbox
$FormLocalAdminFieldTextBoxPcnumber.text = "PC" 
$FormLocalAdminFieldTextBoxPcnumber.location = "5,365" 
$FormLocalAdminFieldTextBoxPcnumber.size = "250,15"
$FormLocalAdmin.Controls.Add($FormLocalAdminFieldTextBoxPcnumber) 
# Button, Creates the local Admin 
$FormLocalAdminBtnProcessCreateAdmin = New-object System.Windows.Forms.Button
$FormLocalAdminBtnProcessCreateAdmin.location = "80,425"  
$FormLocalAdminBtnProcessCreateAdmin.text = "Create Admin"  
$FormLocalAdminBtnProcessCreateAdmin.size = "90,25"  
$FormLocalAdmin.Controls.Add($FormLocalAdminBtnProcessCreateAdmin) # Button, Creates the Admin if the fields have value
$FormLocalAdminBtnProcessCreateAdmin.Add_Click({ ProcessCreateLocalAdmin })       
function ProcessCreateLocalAdmin  { 
$ApplicationFormProgressBar.Value ++
$usernameAd = $FormLocalAdminFieldTextBoxAdAccountUserName.Text
$computerAd = $FormLocalAdminFieldTextBoxPcnumber.Text + "$"
$computerhostname = $FormLocalAdminFieldTextBoxPcnumber.Text 
$username   = $FormLocalAdminFieldTextBoxLocalUsername.Text
$password   = $FormLocalAdminFieldTextBoxLocalPassword.Text
$computers  = $FormLocalAdminFieldTextBoxIpadress.Text
Foreach ($computer in $computers) {
$users = $null
$computer = [ADSI]“WinNT://$computer”
Try {
$users = $computer.psbase.children | select -expand name  
if ($users -like $username) {
$ApplicationFormStatusBarStatusPanel.Text =  "$username already exists"
} Else {   
$user_obj = $computer.Create(“user”, “$username”)
$user_obj.SetPassword($password)
$user_obj.SetInfo()
$user_obj.passwordExpired = 1;
$user_obj.setinfo();
$user_obj.Put(“description”, “Local Admin-Account to user $usernameAd”)
$user_obj.SetInfo()
$user_obj.psbase.invokeset(“AccountDisabled”, “False”)
$user_obj.SetInfo()
$users = $computer.psbase.children | select -expand name
$group = [ADSI]"WinNT://$computers/Administratörer,group"
$group.Add("WinNT://$computers/$username")
if ($users -like $username) {
$ApplicationFormStatusBarStatusPanel.Text =  "$username has been created on $($computer.name)"
# Send to User as email
$SmtpServer = $SmtpAdressToMailServer 
$SmtpUser = $ApplicationFormServiceUserId
$smtpPassword = $ApplicationFormServiceUserPassword
$SmtpUsername = $usernameAd
$SmtpUsernameDomain = $SmtpFqdn
$MailtTo = $SmtpUsername + $SmtpUsernameDomain
$MailFrom = $ApplicationFormServiceUserId
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text =  "Creating Local-Account and sending Mail To user $MailtTo, Wait"
$MailSubject = "Information about your local admin account"
$MailBody = "hi your local admin account is $username with the password $password. In the first textbox you type in  \\$computerhostname\$username as username and in the passwordbox $password "
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $SmtpUser, $($smtpPassword | ConvertTo-SecureString -AsPlainText -Force) 
Send-MailMessage -To "$MailtTo" -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8) -UseSsl -Credential $Credentials

$ApplicationFormProgressBar.Value ++
start-sleep -m 50
$ApplicationFormProgressBar.Value ++
start-sleep -m 50
$ApplicationFormProgressBar.Value = 0;
} Else {
$ApplicationFormStatusBarStatusPanel.Text = "$username has not been created on $($computer.name)"
}
}
} Catch {
$ApplicationFormStatusBarStatusPanel.Text =  "Error creating $username on $($computer.path):  $($Error[0].Exception.Message)"
}

}
LUsrMgr.msc /Computer=$computers
$FormLocalAdmin.Close()
# Skapa sen en process så att det lokal kontot läggs dit automatiskt i lokala admin gruppen
}
# Initlize the Form
$FormLocalAdmin.Add_Shown({$FormLocalAdmin.Activate()})
[void] $FormLocalAdmin.ShowDialog() }

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 8 : Mapp-Enhet
# Send a vb script to public/desktop
# 
#------------------------------------------------------------------------------------#
$TabComputerBtnSendMappaEnheter = New-object System.Windows.Forms.Button 
$TabComputerBtnSendMappaEnheter.text= "MappEnhet"   
$TabComputerBtnSendMappaEnheter.location = "670,167" 
$TabComputerBtnSendMappaEnheter.size = $ValueButtonSize  
$TabComputerBtnSendMappaEnheter.Add_Click({ SendMappaEnheter }) 
$TabComputer.Controls.Add($TabComputerBtnSendMappaEnheter) 
function SendMappaEnheter { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$ApplicationFormProgressBar.Value ++
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
start-sleep -m  100
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = 
$ApplicationLocalAllUserPath =""

$ApplicationMappaenheterpath = ""
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
Copy-Item -Path $ApplicationMappaenheterpath -Destination $ApplicationLocalAllUserPath
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.text = "100 % - Task Completed"
Start-Process -FilePath $ApplicationLocalAllUserPath
start-sleep -m 50
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
}}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 9 : Ping
# Just a button thats test the network connection by ping the computer
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
$TabComputerBtnPingComputers = New-object System.Windows.Forms.Button 
$TabComputerBtnPingComputers.text= "Ping"   
$TabComputerBtnPingComputers.location = "670,188" 
$TabComputerBtnPingComputers.size = $ValueButtonSize  
$TabComputerBtnPingComputers.Add_Click({ TestNetworkConnectionToPc }) 
$TabComputer.Controls.Add($TabComputerBtnPingComputers) 
function TestNetworkConnectionToPc { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$ApplicationFormProgressBar.Value ++
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful"
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
start-sleep -m  100 
start-sleep -s  1.5 
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
 }}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 10 : Process
# Downloads active process from the workstation and populates the listview
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
$TabComputerBtnProcessInfo = New-object System.Windows.Forms.Button 
$TabComputerBtnProcessInfo.text= "Process"   
$TabComputerBtnProcessInfo.location = "670,209" 
$TabComputerBtnProcessInfo.size = $ValueButtonSize  
$TabComputerBtnProcessInfo.Add_Click({ DownloadActiveProcessOnWorkStation }) 
$TabComputer.Controls.Add($TabComputerBtnProcessInfo) 
function DownloadActiveProcessOnWorkStation { 

$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
If ($PingRequest -eq $true) {
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Downloading Active-Process on workstation"
$ApplicationFormProgressBar.Value ++
Initialize-Listview
Update-ContextMenu (Get-Variable CmsProc*)
$XML.Options.Processes.Property | %{Add-Column $_}
Resize-Columns
$Col0 = $lvMain.Columns[0].Text
$Info = Get-WmiObject win32_process -ComputerName $TextbarData -ErrorVariable SysError | Sort Name
Start-Sleep -m 250
if($SysError){$ApplicationFormStatusBarStatusPanel.Text = "[$TextbarData] $SysError"}
else{
$Info | %{
$Item = New-Object System.Windows.Forms.ListViewItem($_.$Col0)
ForEach ($Col in ($lvMain.Columns | ?{$_.Index -ne 0})){
$Field = $Col.Text
$SubItem = $_.$Field
$ApplicationFormStatusBarStatusPanel.text = "Done"
if($SubItem -ne $null){$Item.SubItems.Add($SubItem)}
else{$Item.SubItems.Add("")}}
$lvMain.Items.Add($Item)
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

}}
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
 }}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 11 : Restart Pc
# Restarts the chosen pc, send a confirmation box before the reboot 
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
$TabComputerBtnRestartMachine = New-object System.Windows.Forms.Button 
$TabComputerBtnRestartMachine.text = "Restart PC"     
$TabComputerBtnRestartMachine.location = "670,230" 
$TabComputerBtnRestartMachine.size = $ValueButtonSize 
$TabComputerBtnRestartMachine.Add_Click({ RemoteRestartPc }) 
$TabComputer.Controls.Add($TabComputerBtnRestartMachine) 
function RemoteRestartPc {
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$ApplicationFormProgressBar.Value ++
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
If ($PingRequest -eq $true) { 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100 
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Confirm that you want to restart in the popup "

# Popupmenu restart
$TabComputerBtnRestartMachineForm =  New-Object System.Windows.Forms.Form
$TabComputerBtnRestartMachineForm.text = "Confirm that you want to restart"     
$TabComputerBtnRestartMachineForm.size = "300,80"
$TabComputerBtnRestartMachineForm.StartPosition = "CenterScreen" 
$TabComputerBtnRestartMachineForm.Topmost = $True
$TabComputerBtnRestartMachineForm.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Restart Button
$TabComputerBtnRestartMachineFormBtnRestart = New-object System.Windows.Forms.Button 
$TabComputerBtnRestartMachineFormBtnRestart.text = "Restart "     
$TabComputerBtnRestartMachineFormBtnRestart.location = "75,15" 
$TabComputerBtnRestartMachineFormBtnRestart.size = $ValueButtonSize 
$TabComputerBtnRestartMachineFormBtnRestart.Add_Click({ MachineFormBtnRestart }) 
$TabComputerBtnRestartMachineForm.Controls.Add($TabComputerBtnRestartMachineFormBtnRestart) 
Function MachineFormBtnRestart {
Restart-Computer -Computername $TextbarData -Force
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$TabComputerBtnRestartMachineForm.Close()
}

# Cancel Button 
$TabComputerBtnRestartMachineFormBtnCancel = New-object System.Windows.Forms.Button 
$TabComputerBtnRestartMachineFormBtnCancel.text = "Cancel"     
$TabComputerBtnRestartMachineFormBtnCancel.location = "170,15" 
$TabComputerBtnRestartMachineFormBtnCancel.size = $ValueButtonSize 
$TabComputerBtnRestartMachineFormBtnCancel.Add_Click({ MachineFormBtnCancel }) 
$TabComputerBtnRestartMachineForm.Controls.Add($TabComputerBtnRestartMachineFormBtnCancel) 
Function MachineFormBtnCancel {
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$TabComputerBtnRestartMachineForm.Close()

}
# Initlize the Form
$TabComputerBtnRestartMachineForm.Add_Shown({$TabComputerBtnRestartMachineForm.Activate()})
[void] $TabComputerBtnRestartMachineForm.ShowDialog()
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
 }}



######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 12 : Services
# Downloads service info and pouplates the listview
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
$TabComputerBtnServicesInfo = New-object System.Windows.Forms.Button 
$TabComputerBtnServicesInfo.text= "Services"   
$TabComputerBtnServicesInfo.location = "670,251" 
$TabComputerBtnServicesInfo.size = $ValueButtonSize  
$TabComputerBtnServicesInfo.Add_Click({ DownloadServicesOnWorkStation }) 
$TabComputer.Controls.Add($TabComputerBtnServicesInfo) 
Function DownloadServicesOnWorkStation { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
If ($PingRequest -eq $true) {
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Downloading Services-Information on workstation.ETA 1-10 Sec"
$ApplicationFormProgressBar.Value ++
Initialize-Listview
Update-ContextMenu (Get-Variable CmsSrv*)
$XML.Options.Services.Property | %{Add-Column $_}
Resize-Columns
$Col0 = $lvMain.Columns[0].Text
$Info = Get-WmiObject Win32_Service -ComputerName $TextbarData -ErrorVariable SysError | Sort Name
Start-Sleep -m 100
if($SysError){$ApplicationFormStatusBarStatusPanel.Text = "[$TextbarData] $SysError"}
else{
$Info | %{
$Item = New-Object System.Windows.Forms.ListViewItem($_.$Col0)
ForEach ($Col in ($lvMain.Columns | ?{$_.Index -ne 0})){$Field = $Col.Text;$Item.SubItems.Add($_.$Field)}
$lvMain.Items.Add($Item)}}
Start-Sleep -m 100
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
 }}


######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 13 : Send File
# Sends File to the Pc, Public / Desktop
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
$TabComputerBtnSendFileToMachine = New-object System.Windows.Forms.Button 
$TabComputerBtnSendFileToMachine.text= "Send File"   
$TabComputerBtnSendFileToMachine.location = "670,272" 
$TabComputerBtnSendFileToMachine.size = $ValueButtonSize  
$TabComputerBtnSendFileToMachine.Add_Click({ GenerateFormSendFile }) 
$TabComputer.Controls.Add($TabComputerBtnSendFileToMachine) 
function GenerateFormSendFile {
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
If ($PingRequest -eq $true) {
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Creating Send-Form"
$ApplicationFormProgressBar.Value ++

#Generated Form
$FormSendFile = New-Object System.Windows.Forms.Form
$FormSendFile.Text = "Send A file To $TextbarData" 
$FormSendFile.StartPosition = "CenterScreen"
$FormSendFile.Topmost = $false 
$FormSendFile.Size =  "400,125"
$FormSendFile.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : FilePath
$FormSendFileLabelFilePath = New-object System.Windows.Forms.Label   
$FormSendFileLabelFilePath.location = "90,5" 
$FormSendFileLabelFilePath.size = "250,20"
$FormSendFileLabelFilePath.text = "File-Path"
$FormSendFile.Controls.Add($FormSendFileLabelFilePath)
# Textbar to filepath
$FormSendFileTextbarFilePath = New-object System.Windows.Forms.Textbox   
$FormSendFileTextbarFilePath.location = "5,30" 
$FormSendFileTextbarFilePath.size = "250,20"
$FormSendFile.Controls.Add($FormSendFileTextbarFilePath)
# Browse Button
$FormSendFileBtnBrowseAfterFiles = New-object System.Windows.Forms.Button 
$FormSendFileBtnBrowseAfterFiles.text= "Browse"   
$FormSendFileBtnBrowseAfterFiles.location = "265,30" 
$FormSendFileBtnBrowseAfterFiles.size = $ValueButtonSize  
$FormSendFileBtnBrowseAfterFiles.Add_Click({ BrowseAfterFiles }) 
$FormSendFile.Controls.Add($FormSendFileBtnBrowseAfterFiles)
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
function BrowseAfterFiles { 
$FormSendFileOpenFileDialogFileBrowser = New-object System.Windows.Forms.OpenFileDialog
# Path To the Fileserver
$FormSendFileOpenFileDialogFileBrowser.initialDirectory = $FormInstallOpenFileDialogFileBrowserinitialDirectory
$FormSendFileOpenFileDialogFileBrowser.Title = "$ApplicationTitle $ApplicationVersion" 
$FormSendFileOpenFileDialogFileBrowser.Multiselect = $false
$FormSendFileOpenFileDialogFileBrowser.showHelp = $true
$FormSendFileOpenFileDialogFileBrowser.ShowDialog() 
foreach($FormSendFileOpenFileDialogFileBrowser in $FormSendFileOpenFileDialogFileBrowser.FileNames)
{ $FormSendFileTextbarFilePath.text = $FormSendFileOpenFileDialogFileBrowser }} 
# Send File Button
$FormSendFileBtnSendFiles = New-object System.Windows.Forms.Button 
$FormSendFileBtnSendFiles.text= "Send File"   
$FormSendFileBtnSendFiles.location = "265,60" 
$FormSendFileBtnSendFiles.size = $ValueButtonSize  
$FormSendFileBtnSendFiles.Add_Click({ BtnSendFiles }) 
$FormSendFile.Controls.Add($FormSendFileBtnSendFiles)
function BtnSendFiles {
TextConfirmationData
$ApplicationFormProgressBar.Value ++
$SendFileLocalAllUserPath ="\\$TextbarData\c$\Users\Public\Desktop"
Copy-Item -Path $FormSendFileTextbarFilePath.text -Destination $SendFileLocalAllUserPath
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = " Sending File "
$ApplicationFormProgressBar.Value ++
start-sleep -m  250
$ApplicationFormStatusBarStatusPanel.Text = "Task Completed "
start-sleep -m  250
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$FormSendFile.close()
}

# Initlize the FormSendMessage
$FormSendFile.Add_Shown({$FormSendFile.Activate()})
[void] $FormSendFile.ShowDialog()}}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 14 : Send Mess
# Send a pop-up message to the machine
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
$TabComputerBtnSendMessToMachine = New-object System.Windows.Forms.Button 
$TabComputerBtnSendMessToMachine.text= "Send Mess"   
$TabComputerBtnSendMessToMachine.location = "670,293" 
$TabComputerBtnSendMessToMachine.size = $ValueButtonSize  
$TabComputerBtnSendMessToMachine.Add_Click({ GenerateFormSendMess }) 
$TabComputer.Controls.Add($TabComputerBtnSendMessToMachine) 
function GenerateFormSendMess { 
$ApplicationFormProgressBar.Value = 0
$ApplicationFormProgressBar.Maximum = $total*4 + 4
$TextbarData = $ApplicationFormTextBarSearchBar.Text

$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
start-sleep -m  250
If ($PingRequest -eq $true) { 
$ApplicationFormStatusBarStatusPanel.Text = "Ping successful, Creating Send-Form"
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

#Generated Form
$FormSendMessage = New-Object System.Windows.Forms.Form
$FormSendMessage.Text = "Send A Message To $TextbarData" 
$FormSendMessage.StartPosition = "CenterScreen"
$FormSendMessage.Topmost = $false 
$FormSendMessage.MinimumSize = "600,350"
$FormSendMessage.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Exit button
$FormSendMessageButtonExit = New-object System.Windows.Forms.Button
$FormSendMessageButtonExit.text= "Exit"   
$FormSendMessageButtonExit.location = "470,255" 
$FormSendMessageButtonExit.size = $ValueButtonSize
$FormSendMessageButtonExit.Add_Click({$FormSendMessage.Close()} )
$FormSendMessage.Controls.Add($FormSendMessageButtonExit)
# Send mess button
$FormSendMessageButtonSendMess = New-object System.Windows.Forms.Button
$FormSendMessageButtonSendMess.text= "Send Mess"   
$FormSendMessageButtonSendMess.location = "470,25" 
$FormSendMessageButtonSendMess.size = $ValueButtonSize 
$FormSendMessageButtonSendMess.Add_Click({ SendingMessToPc })
$FormSendMessage.Controls.Add($FormSendMessageButtonSendMess)
# Rich textbox
$FormSendMessageRichTextboxData = New-object System.Windows.Forms.richtextbox
$FormSendMessageRichTextboxData.location = "5,25" 
$FormSendMessageRichTextboxData.size = "400,250" 
$FormSendMessageRichTextboxData.ScrollBars = "Vertical" 
$FormSendMessageRichTextboxData.font ="lucida console"
$FormSendMessageRichTextboxData.text = "/ Mvh IT-Enheten"
$FormSendMessage.Controls.Add($FormSendMessageRichTextboxData)
function SendingMessToPc {
$TextbarData = $ApplicationFormTextBarSearchBar.Text
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++ 
If ($PingRequest -eq $true) { 
$msg = $SendMessageFormRichTextboxData.text
Invoke-WmiMethod -Path Win32_Process -Name Create -ArgumentList "msg * $msg" -ComputerName $TextbarData
start-sleep -m  100
$ApplicationFormProgressBar.Value ++ 
$ApplicationFormStatusBarStatusPanel.Text = "Task Completed "
start-sleep -m  250
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$FormSendMessage.Close()
} else {
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Failed to connect, try ipadress"}}
# Initlize the FormSendMessage
$FormSendMessage.Add_Shown({$FormSendMessage.Activate()})
[void] $FormSendMessage.ShowDialog()}}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 15 : Startup-Information
# Downloads Startup-information to listview
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
$TabComputerBtnStartupInfo = New-object System.Windows.Forms.Button 
$TabComputerBtnStartupInfo.text= "Startup"   
$TabComputerBtnStartupInfo.location = "670,314" 
$TabComputerBtnStartupInfo.size = $ValueButtonSize  
$TabComputerBtnStartupInfo.Add_Click({ DownloadStartupOnWorkStation }) 
$TabComputer.Controls.Add($TabComputerBtnStartupInfo) 
Function DownloadStartupOnWorkStation { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
If ($PingRequest -eq $true) {
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Downloading Startup-Information on workstation"
$ApplicationFormProgressBar.Value ++
Initialize-Listview
Update-ContextMenu (Get-Variable cmsStart*)
$XML.Options.StartupItems.Property | %{Add-Column $_}
Resize-Columns
$Col0 = $lvMain.Columns[0].Text

$Info = Get-WmiObject win32_StartupCommand -ComputerName $TextbarData -ErrorVariable SysError | Sort Name
Start-Sleep -m 100
if($SysError){$ApplicationFormStatusBarStatusPanel.Text = "[$TextbarData] $SysError"}

else{
$Info | %{
$Item = New-Object System.Windows.Forms.ListViewItem($_.$Col0)
ForEach ($Col in ($lvMain.Columns | ?{$_.Index -ne 0})){$Field = $Col.Text;$Item.SubItems.Add($_.$Field)}
$lvMain.Items.Add($Item)
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
Start-Sleep -m 100
$ApplicationFormStatusBarStatusPanel.text = "Ready"
}}

} else { 
$ApplicationFormStatusBarStatusPanel.text = "Failed To Connect, Try Ip-Adress"
$ApplicationFormProgressBar.Value = 0;
 }}


######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 16 : System-Information
# Downloads system-information to listview
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
$TabComputerBtnSysInfo = New-object System.Windows.Forms.Button 
$TabComputerBtnSysInfo.text= "Sys-Info"
$TabComputerBtnSysInfo.location = "670,335" 
$TabComputerBtnSysInfo.size = $ValueButtonSize  
$TabComputerBtnSysInfo.Add_Click({ DownloadSystemInfoOnWorkStation }) 
$TabComputer.Controls.Add($TabComputerBtnSysInfo) 
Function DownloadSystemInfoOnWorkStation { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationData
$PingRequest = Test-Connection -ComputerName $TextbarData -Count 1 -Quiet 
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
If ($PingRequest -eq $true) {
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Downloading System-Information on workstation, ETA 10 Sec"
$ApplicationFormProgressBar.Value ++
Initialize-Listview
Update-ContextMenu (Get-Variable cmsSystem*)
$SysError = $null
$sysComp = Get-WmiObject Win32_ComputerSystem -ComputerName $TextbarData -ErrorVariable SysError
Start-Sleep -m 250
if($SysError){$ApplicationFormStatusBarStatusPanel.Text = "[$TextbarData] $SysError"}
else{
$sysComp2 = Get-WmiObject Win32_ComputerSystemProduct -ComputerName $TextbarData
$sysOS = Get-WmiObject Win32_OperatingSystem -ComputerName $TextbarData
$sysBIOS = Get-WmiObject Win32_BIOS -ComputerName $TextbarData
$sysCPU = Get-WmiObject Win32_Processor -ComputerName $TextbarData
$sysRAM = Get-WmiObject Win32_PhysicalMemory -ComputerName $TextbarData
$sysNAC = Get-WmiObject Win32_NetworkAdapterConfiguration -ComputerName $TextbarData -Filter "IPEnabled='True'"
$sysMon = Get-WmiObject Win32_DesktopMonitor -ComputerName $TextbarData
$sysVid = Get-WmiObject Win32_VideoController -ComputerName $TextbarData
$sysOD = Get-WmiObject Win32_CDROMDrive -ComputerName $TextbarData
$sysHD = Get-WmiObject Win32_LogicalDisk -ComputerName $TextbarData
$sysProc = Get-WmiObject Win32_Process -ComputerName $TextbarData
"Property","Value" | %{Add-Column $_}
if ($XML.Options.SystemInfo.General.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("General")
$Item.BackColor = "Black"
$Item.ForeColor = "White"
$lvMain.Items.Add($Item)
if($XML.Options.SystemInfo.General.ComputerName.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Computer Name")
$Item.SubItems.Add($sysComp.Name)
$lvMain.Items.Add($Item)}				
if($XML.Options.SystemInfo.General.CurrentUser.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("User")
if($SysComp.UserName -ne $null){$Item.SubItems.Add($sysComp.UserName)}
else{$Item.SubItems.Add("")}					
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.General.LogonTime.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("User Logon")
if($sysProc | ?{$_.Name -eq "explorer.exe"}){
$UserLogonDT = ($sysProc | ?{$_.Name -eq "explorer.exe"} | Sort CreationDate | Select-Object -First 1).CreationDate
$UserLogon = [System.Management.ManagementDateTimeconverter]::ToDateTime($UserLogonDT).ToString()
$Item.SubItems.Add($UserLogon)
}else{
$Item.SubItems.Add("N/A")}
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.General.ScreenSaverTime.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Screensaver Time")
if($sysProc | ?{$_.Name -match ".scr"}){
$ScreensaverTime = ($sysProc | ?{$_.Name -match ".scr"} | Sort CreationDate | Select-Object -First 1).CreationDate
$Screensaver = [System.Management.ManagementDateTimeconverter]::ToDateTime($ScreensaverTime).ToString()
$Item.SubItems.Add($Screensaver)
}else{
$Item.SubItems.Add("N/A")}
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.General.LastRestart.Enabled -eq $true){
$LastBootUpTime = [System.Management.ManagementDateTimeconverter]::ToDateTime($sysOS.LastBootUpTime).ToString()
$Item = New-Object System.Windows.Forms.ListViewItem("Last Restart")
$Item.SubItems.Add($LastBootUpTime)
$lvMain.Items.Add($Item)}}
if ($XML.Options.SystemInfo.Build.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Build")
$Item.BackColor = "Black"
$Item.ForeColor = "White"
$lvMain.Items.Add($Item)
if($XML.Options.SystemInfo.Build.Manufacturer.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Manufacturer")
$Item.SubItems.Add($sysComp.Manufacturer)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.Build.Model.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Model")
$Item.SubItems.Add($sysComp.Model)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.Build.Chassis.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Chassis")
$Item.SubItems.Add($sysComp2.Version)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.Build.Serial.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Serial")
$Item.SubItems.Add($sysBIOS.SerialNumber)
$lvMain.Items.Add($Item)}}
if ($XML.Options.SystemInfo.Hardware.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Hardware")
$Item.BackColor = "Black"
$Item.ForeColor = "White"
$lvMain.Items.Add($Item)
if($XML.Options.SystemInfo.Hardware.CPU.Enabled -eq $true){
$sysCPU | %{
$Item = New-Object System.Windows.Forms.ListViewItem("CPU")
$Item.SubItems.Add($sysCPU.Name.Trim())
$lvMain.Items.Add($Item)}}
if($XML.Options.SystemInfo.Hardware.RAM.Enabled -eq $true){
$tRAM = "{0:N2} GB Usable - " -f $($sysComp.TotalPhysicalMemory / 1GB)
$sysRAM | %{$tRAM += "[$($_.Capacity / 1GB)] "}
$Item = New-Object System.Windows.Forms.ListViewItem("RAM")
$Item.SubItems.Add($tRAM)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.Hardware.HD.Enabled -eq $true){
$sysHD | ?{$_.DriveType -eq 3} | %{
$HDInfo = "{0:N1} GB Free / {1:N1} GB Total" -f ($_.FreeSpace / 1GB), ($_.Size / 1GB)
$Item = New-Object System.Windows.Forms.ListViewItem("HD")
$Item.SubItems.Add($HDinfo)
$lvMain.Items.Add($Item)}}
if($XML.Options.SystemInfo.Hardware.OpticalDrive.Enabled -eq $true){
$sysOD | %{
$Item = New-Object System.Windows.Forms.ListViewItem("Optical Drive")
$Item.SubItems.Add("[$($sysOD.Drive)] $($sysOD.Caption)")
$lvMain.Items.Add($Item)}}
if($XML.Options.SystemInfo.Hardware.GPU.Enabled -eq $true){
$sysVid | ?{$_.AdapterRAM -gt 0} | %{
$Item = New-Object System.Windows.Forms.ListViewItem("GPU")
$Item.SubItems.Add($_.Name)
$lvMain.Items.Add($Item)}}
if($XML.Options.SystemInfo.Hardware.Monitor.Enabled -eq $true){
$Monitors = $null
$sysMON | %{$Monitors += "[{0} x {1}] " -f $_.ScreenWidth,$_.ScreenHeight}
$Item = New-Object System.Windows.Forms.ListViewItem("Monitor(s)")
$Item.SubItems.Add($Monitors)
$lvMain.Items.Add($Item)}}
if ($XML.Options.SystemInfo.OS.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Operating System")
$Item.BackColor = "Black"
$Item.ForeColor = "White"
$lvMain.Items.Add($Item)
if($XML.Options.SystemInfo.OS.OS.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("OS Name")
$Item.SubItems.Add($sysOS.Caption)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.OS.ServicePack.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Service Pack")
$Item.SubItems.Add($sysOS.CSDVersion)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.OS.Architecture.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("OS Architecture")
$Item.SubItems.Add($sysComp.SystemType)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.OS.ImageDate.Enabled -eq $true){
$InstallDate = [System.Management.ManagementDateTimeconverter]::ToDateTime($sysOS.InstallDate).ToString()
$Item = New-Object System.Windows.Forms.ListViewItem("Install Date")
$Item.SubItems.Add($InstallDate)
$lvMain.Items.Add($Item)}}
if ($XML.Options.SystemInfo.IPConfig.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Network Adapters")
$Item.BackColor = "Black"
$Item.ForeColor = "White"
$lvMain.Items.Add($Item)
$sysNAC | %{
if($XML.Options.SystemInfo.IPConfig.Description.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("Description")
$Item.SubItems.Add($_.Description)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.IPConfig.IPAddress.Enabled -eq $true){
$IPinfo = $null
ForEach ($IP in $_.IPAddress){$IPinfo += "$IP "}
$Item = New-Object System.Windows.Forms.ListViewItem("IP Address")
$Item.SubItems.Add($IPinfo)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.IPConfig.MACAddress.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("MAC Address")
$Item.SubItems.Add($_.MACAddress)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.IPConfig.DHCPEnabled.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("DHCP Enabled")
$Item.SubItems.Add($_.DHCPEnabled.ToString())
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.IPConfig.DHCPServer.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("DHCP Server")
$Item.SubItems.Add($_.DHCPServer)
$lvMain.Items.Add($Item)}
if($XML.Options.SystemInfo.IPConfig.DNSDomain.Enabled -eq $true){
$Item = New-Object System.Windows.Forms.ListViewItem("DNS Domain")
$Item.SubItems.Add($_.DNSDomain)
$lvMain.Items.Add($Item)}}}
$lvMain.Columns[0].Width = "120"
$lvMain.Columns[1].Width = ($lvMain.Width - ($lvMain.Columns[0].Width + 22))
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
Start-Sleep -m 100
$ApplicationFormStatusBarStatusPanel.text = "Ready"
}}}


#-------------------------------------------------------------------------------------#
#######################################################################################
#######################################################################################
#######################################################################################

######################################################################################
# Static Functions For Computer Tab 
# 
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
function TextConfirmationData {
$ApplicationFormProgressBar.Maximum = $total*4 + 4
$ApplicationFormStatusBarStatusPanel.Text = "Checking Network-Connection to $TextbarData"
}

function Get-ColumnIndex{
Param($ColumnName)
$Script:ColumnIndex = ($lvMain.Columns | ?{$_.Text -eq $ColumnName}).Index
}	
function Update-ContextMenu{
Param($Vis)		
Get-Variable Cms* | %{Try{$_.Value.Visible = $False}catch{}}
$Vis | %{try{$_.Value.Visible = $True}catch{}}
}	
function Initialize-Listview{
$lvMain.Items.Clear()
$lvMain.Columns.Clear()
}		
function Add-Column{
Param([String]$Column)
Write-Verbose "Adding $Column from XML file"
$lvMain.Columns.Add($Column)
}	
function Resize-Columns{
Write-Verbose "Resizing columns based on column count"
$ColWidth = (($lvMain.Width / ($lvMain.Columns).Count) - 11)
$lvMain.Columns | %{$_.Width = $ColWidth}
}	
function Remove-SelectedItems{
$lvMain.SelectedItems | %{$lvMain.Items.RemoveAt($_.Index)}
}



#-----------------------------------------------------------------------------------#
#######################################################################################
#######################################################################################
#######################################################################################

#######################################################################################
############################# Active Directory Computers Tab ##########################
#######################################################################################
$TabADComputer = New-object System.Windows.Forms.Tabpage
$TabADComputer.DataBindings.DefaultDataSourceUpdateMode = 0 
$TabADComputer.UseVisualStyleBackColor = $True 
$TabADComputer.Name = "TabActiveDirectoryComputer" 
$TabADComputer.Text = "Active Directory Computers” 
$FormTabControl.Controls.Add($TabADComputer)  

######################################################################################
# MainTab - Tabcontrol - TabADComputer - Listview 
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$RichTextBoxADComputer = New-Object System.Windows.Forms.richtextbox
$RichTextBoxADComputer.Location = "5, 21"
$RichTextBoxADComputer.Name = "RichTextBoxADComputer"
$RichTextBoxADComputer.Size = "650, 418"
$RichTextBoxADComputer.ScrollBars = "Vertical" 
$RichTextBoxADComputer.font ="lucida console"
$TabADComputer.Controls.Add($RichTextBoxADComputer) 


######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 1 : App-Info
# Downloads a information from AD
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$TabADComputerBtnAdInfo = New-object System.Windows.Forms.Button 
$TabADComputerBtnAdInfo.text= "Ad-Info"   
$TabADComputerBtnAdInfo.location = "670,20" 
$TabADComputerBtnAdInfo.size = $ValueButtonSize  
$TabADComputerBtnAdInfo.Add_Click({ BtnAdInfoComputer }) 
$TabADComputer.Controls.Add($TabADComputerBtnAdInfo) 
function BtnAdInfoComputer { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationAdComputer
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Downloading Information From Ad"
$ApplicationFormProgressBar.Value ++
# Powershell get-adcomputer
$GetAdComputerAttributes = Get-ADComputer -Identity $TextbarData -Properties Name, Cn, DNSHostName, CanonicalName, SamAccountName, whenChanged, whenCreated, modifyTimeStamp, Enabled, OperatingSystem, OperatingSystemServicePack, OperatingSystemVersion, IPv4Address, LastLogonDate, LastLogon, badPasswordTime, ObjectSid, ObjectGuid | 
Format-list Name, Cn, DNSHostName, CanonicalName, SamAccountName, whenChanged, whenCreated, modifyTimeStamp, Enabled, OperatingSystem, OperatingSystemServicePack, OperatingSystemVersion, IPv4Address, LastLogonDate, LastLogonDate, @{N='LastLogon'; E={[DateTime]::FromFileTime($_.LastLogon)}}, @{N='badPasswordTime'; E={[DateTime]::FromFileTime($_.badPasswordTime)}}, ObjectSid, ObjectGuid | out-string;    
$AdcomputerSamaccountName = "$"
$TextbarDataSam = $TextbarData + $AdcomputerSamaccountName
$GetAdComputerMembersOf = Get-ADPrincipalGroupMembership $TextbarDataSam | sort name | select name | out-string
$RichTextBoxADComputerADgroups = "Ad-Groups"
$RichTextBoxADComputerADAttributes = "Ad-Attributes"
# Export to the richtextbox
$RichTextBoxADComputer.text = $RichTextBoxADComputerADAttributes+$GetAdComputerAttributes + $RichTextBoxADComputerADgroups + $GetAdComputerMembersOf 
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"

}

######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 2 : Copy-info
# Copies a computer members of to another one
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$TabADComputerBtnAdInfoCopyMembersOf = New-object System.Windows.Forms.Button 
$TabADComputerBtnAdInfoCopyMembersOf.text= "Copy Members"   
$TabADComputerBtnAdInfoCopyMembersOf.location = "670,41" 
$TabADComputerBtnAdInfoCopyMembersOf.size = $ValueButtonSize  
$TabADComputerBtnAdInfoCopyMembersOf.Add_Click({ BtnAdInfoCopyMembersOf }) 
$TabADComputer.Controls.Add($TabADComputerBtnAdInfoCopyMembersOf) 
function BtnAdInfoCopyMembersOf { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationAdComputer

#Generated Form
$FormComputerCopyMembersOf = New-Object System.Windows.Forms.Form
$FormComputerCopyMembersOf.Text = " Copy Computers Members Of And OU From $TextbarData" 
$FormComputerCopyMembersOf.StartPosition = "CenterScreen"
$FormComputerCopyMembersOf.Topmost = $false 
$FormComputerCopyMembersOf.MinimumSize = "390,300"
$FormComputerCopyMembersOf.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
 
# Label "Copy Members To This PC" 
$FormComputerCopyMembersToLabel = New-Object System.Windows.Forms.Label
$FormComputerCopyMembersToLabel.text = "Copy Members To This PC"   
$FormComputerCopyMembersToLabel.location = "35,15" 
$FormComputerCopyMembersToLabel.size = "200,20"
$FormComputerCopyMembersOf.Controls.Add($FormComputerCopyMembersToLabel) 
# Textbox Copy To this 
$FormComputerCopyMembersToTextbox = New-Object System.Windows.Forms.textbox
$FormComputerCopyMembersToTextbox.text = "PC"   
$FormComputerCopyMembersToTextbox.location = "15,35" 
$FormComputerCopyMembersToTextbox.size = "200,20"
$FormComputerCopyMembersOf.Controls.Add($FormComputerCopyMembersToTextbox)
 
# Checkbox Remove the Old MembersOf from object in FormComputerCopyMembersToTextbox
$FormComputerCopyMembersOfCheckboxRemoveOldMembersOf = New-Object System.Windows.Forms.Checkbox
$FormComputerCopyMembersOfCheckboxRemoveOldMembersOf.text = "Clear MembersOf On The New Pc "   
$FormComputerCopyMembersOfCheckboxRemoveOldMembersOf.location = "15,65" 
$FormComputerCopyMembersOfCheckboxRemoveOldMembersOf.size = "300,20"
$FormComputerCopyMembersOf.Controls.Add($FormComputerCopyMembersOfCheckboxRemoveOldMembersOf) 

# Label Move Computer to OU 
$FormComputerCopyMembersToLabelMoveComputerOu = New-Object System.Windows.Forms.Label
$FormComputerCopyMembersToLabelMoveComputerOu.text = "Move Computer To OU"   
$FormComputerCopyMembersToLabelMoveComputerOu.location = "15,100" 
$FormComputerCopyMembersToLabelMoveComputerOu.size = "200,20"
$FormComputerCopyMembersOf.Controls.Add($FormComputerCopyMembersToLabelMoveComputerOu) 
 
# Move FormComputerCopyMembersOfTextbox To Adm OU
$FormComputerCopyMembersOfCheckboxMovePcToAdm = New-Object System.Windows.Forms.Checkbox
$FormComputerCopyMembersOfCheckboxMovePcToAdm.text = "Adm OU"   
$FormComputerCopyMembersOfCheckboxMovePcToAdm.location = "15,120" 
$FormComputerCopyMembersOfCheckboxMovePcToAdm.size = "80,20"
$FormComputerCopyMembersOf.Controls.Add($FormComputerCopyMembersOfCheckboxMovePcToAdm) 

# Move FormComputerCopyMembersOfTextbox To Adm-Grupp OU
$FormComputerCopyMembersOfCheckboxMovePcToAdmGrupp = New-Object System.Windows.Forms.Checkbox
$FormComputerCopyMembersOfCheckboxMovePcToAdmGrupp.text = "Adm-Grupp OU"   
$FormComputerCopyMembersOfCheckboxMovePcToAdmGrupp.location = "100,120" 
$FormComputerCopyMembersOfCheckboxMovePcToAdmGrupp.size = "120,20"
$FormComputerCopyMembersOf.Controls.Add($FormComputerCopyMembersOfCheckboxMovePcToAdmGrupp) 

# Move FormComputerCopyMembersOfTextbox To Ped OU
$FormComputerCopyMembersOfCheckboxMovePcToPed = New-Object System.Windows.Forms.Checkbox
$FormComputerCopyMembersOfCheckboxMovePcToPed.text = "Ped OU"   
$FormComputerCopyMembersOfCheckboxMovePcToPed.location = "15,140" 
$FormComputerCopyMembersOfCheckboxMovePcToPed.size = "80,20"
$FormComputerCopyMembersOf.Controls.Add($FormComputerCopyMembersOfCheckboxMovePcToPed) 

# Move FormComputerCopyMembersOfTextbox To Ped-Grupp OU
$FormComputerCopyMembersOfCheckboxMovePcToPedGrupp = New-Object System.Windows.Forms.Checkbox
$FormComputerCopyMembersOfCheckboxMovePcToPedGrupp.text = "Ped-Grupp OU"   
$FormComputerCopyMembersOfCheckboxMovePcToPedGrupp.location = "100,140" 
$FormComputerCopyMembersOfCheckboxMovePcToPedGrupp.size = "120,20"
$FormComputerCopyMembersOf.Controls.Add($FormComputerCopyMembersOfCheckboxMovePcToPedGrupp) 

# Move FormComputerCopyMembersOfTextbox To Pub OU
$FormComputerCopyMembersOfCheckboxMovePcToPubOu = New-Object System.Windows.Forms.Checkbox
$FormComputerCopyMembersOfCheckboxMovePcToPubOu.text = "Pub OU"   
$FormComputerCopyMembersOfCheckboxMovePcToPubOu.location = "15,160" 
$FormComputerCopyMembersOfCheckboxMovePcToPubOu.size = "80,20"
$FormComputerCopyMembersOf.Controls.Add($FormComputerCopyMembersOfCheckboxMovePcToPubOu) 

# Button Start Process
$FormComputerCopyMembersOfCheckboxRemoveOldMembersOf = New-Object System.Windows.Forms.Button
$FormComputerCopyMembersOfCheckboxRemoveOldMembersOf.text = "Start Copy"   
$FormComputerCopyMembersOfCheckboxRemoveOldMembersOf.location = "75,225" 
$FormComputerCopyMembersOfCheckboxRemoveOldMembersOf.size = $ValueButtonSize 
$FormComputerCopyMembersOfCheckboxRemoveOldMembersOf.Add_Click({ BtnAdCompCopyMembersOf }) 
$FormComputerCopyMembersOf.Controls.Add($FormComputerCopyMembersOfCheckboxRemoveOldMembersOf) 
function BtnAdCompCopyMembersOf {
$AdcomputerSamaccountName = "$"
$TextbarData = $ApplicationFormTextBarSearchBar.Text
#
$CopyFromThisComputer = $TextbarData
$CopyToThisComputer = $FormComputerCopyMembersToTextbox.text
#
$CopyFromThisComputerSam = $CopyFromThisComputer + $AdcomputerSamaccountName
$CopyToThisComputerSam = $CopyToThisComputer + $AdcomputerSamaccountName
#
$TargetAdmOu = "OU=Datorer-Adm,OU=Datorer,OU=Ls,DC=lidingo,DC=local" 
$TargetAdmGruppOu = "OU=Datorer-AdmGrupp,OU=Datorer,OU=Ls,DC=lidingo,DC=local"

$TargetPedOu = "OU=Datorer-Ped,OU=Datorer,OU=Ls,DC=lidingo,DC=local" 
$TargetPedGruppOu = "OU=Datorer-PedGrupp,OU=Datorer,OU=Ls,DC=lidingo,DC=local"

$TargetPubOu = "OU=Datorer-Pub,OU=Datorer,OU=Ls,DC=lidingo,DC=local"
#

# Remove the old members of on the  $CopyToThisComputerSam
If ($FormComputerCopyMembersOfCheckboxRemoveOldMembersOf.Checked){ 
$ApplicationFormStatusBarStatusPanel.text = "Removing Old MembersOf On $CopyToThisComputer"
Get-ADComputer -identity $CopyToThisComputerSam  -properties memberof | select-object memberof -expandproperty memberof | Remove-ADGroupMember -Members $CopyToThisComputerSam
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"} 
start-sleep -m 250

# Copying members of from textbardata to the CopyToThisComputerSam
$ApplicationFormStatusBarStatusPanel.text = "Copying MembersOf On $CopyFromThisComputer To $CopyToThisComputer"
start-sleep -m 250
Get-ADComputer -identity $CopyFromThisComputer -properties memberof | select-object memberof -expandproperty memberof | Add-AdGroupMember -Members $CopyToThisComputerSam
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
start-sleep -m 250

# Move the computer to Adm OU
If ($FormComputerCopyMembersOfCheckboxMovePcToAdm.Checked){ 
$ApplicationFormStatusBarStatusPanel.text = "Moving $CopyToThisComputer To Adm OU"
start-sleep -m 250
Get-ADComputer $CopyToThisComputerSam | Move-ADObject -TargetPath $TargetAdmOu 
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"} 
  
# Move the computer to AamGrupp OU
If ($FormComputerCopyMembersOfCheckboxMovePcToAdmGrupp.Checked){ 
$ApplicationFormStatusBarStatusPanel.text = "Moving $CopyToThisComputer To Adm-Grupp OU"
start-sleep -m 250
Get-ADComputer $CopyToThisComputerSam | Move-ADObject -TargetPath $TargetAdmGruppOu 
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"} 

# Move the computer to Ped OU
If ($FormComputerCopyMembersOfCheckboxMovePcToPed.Checked){ 
$ApplicationFormStatusBarStatusPanel.text = "Moving $CopyToThisComputer Ped OU"
start-sleep -m 250
Get-ADComputer $CopyToThisComputerSam | Move-ADObject -TargetPath $TargetPedOu 
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"} 

# Move the computer to PedGrupp OU
If ($FormComputerCopyMembersOfCheckboxMovePcToPedGrupp.Checked){ 
$ApplicationFormStatusBarStatusPanel.text = "Moving $CopyToThisComputer PedGrupp OU"
start-sleep -m 250
Get-ADComputer $CopyToThisComputerSam | Move-ADObject -TargetPath $TargetPedGruppOu 
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"} 

# Move the computer to Pub OU
If ($FormComputerCopyMembersOfCheckboxMovePcToPubOu.Checked){ 
$ApplicationFormStatusBarStatusPanel.text = "Moving $CopyToThisComputer Pub OU"
start-sleep -m 250
Get-ADComputer $CopyToThisComputerSam | Move-ADObject -TargetPath $TargetPubOu 
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"} 


$FormComputerCopyMembersOf.Close()
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"

start-sleep -m 250
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready" }

# Initlize the FormComputerCopyMembersOf
$FormComputerCopyMembersOf.Add_Shown({$FormComputerCopyMembersOf.Activate()})
[void] $FormComputerCopyMembersOf.ShowDialog() }


######################################################################################
# MainTab - Tabcontrol - Computer Tab - Button 3 : Email-info
# Mails Computers Ad Attributes and memberof
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$TabADComputerBtnAdInfoEmailInfo = New-object System.Windows.Forms.Button 
$TabADComputerBtnAdInfoEmailInfo.text= "Email Info"   
$TabADComputerBtnAdInfoEmailInfo.location = "670,62" 
$TabADComputerBtnAdInfoEmailInfo.size = $ValueButtonSize  
$TabADComputerBtnAdInfoEmailInfo.Add_Click({ BtnAdEmailInfo }) 
$TabADComputer.Controls.Add($TabADComputerBtnAdInfoEmailInfo) 
function BtnAdEmailInfo { 
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextConfirmationAdComputer

$FormAdComputerInfoSendThisAsEmail = New-Object System.Windows.Forms.Form
$FormAdComputerInfoSendThisAsEmail.Text = "E-Mail Computer AD-Information" 
$FormAdComputerInfoSendThisAsEmail.StartPosition = "CenterScreen"
$FormAdComputerInfoSendThisAsEmail.Topmost = $false 
$FormAdComputerInfoSendThisAsEmail.Size = "350,100"
$FormAdComputerInfoSendThisAsEmail.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : Username
$FormAdComputerInfoSendThisAsEmailLabelUsername = New-object System.Windows.Forms.Label   
$FormAdComputerInfoSendThisAsEmailLabelUsername.location = "90,5" 
$FormAdComputerInfoSendThisAsEmailLabelUsername.size = "250,20"
$FormAdComputerInfoSendThisAsEmailLabelUsername.text = "Username"
$FormAdComputerInfoSendThisAsEmail.Controls.Add($FormAdComputerInfoSendThisAsEmailLabelUsername)
# Textbar Username
$FormAdComputerInfoSendThisAsEmailTextbarUsername = New-object System.Windows.Forms.Textbox   
$FormAdComputerInfoSendThisAsEmailTextbarUsername.location = "5,30" 
$FormAdComputerInfoSendThisAsEmailTextbarUsername.size = "250,20"
$FormAdComputerInfoSendThisAsEmail.Controls.Add($FormAdComputerInfoSendThisAsEmailTextbarUsername)

# Send Button
$FormAdComputerInfoSendThisAsEmailButtonSend = New-object System.Windows.Forms.Button 
$FormAdComputerInfoSendThisAsEmailButtonSend.text= "Send E-Mail"   
$FormAdComputerInfoSendThisAsEmailButtonSend.location = "265,30" 
$FormAdComputerInfoSendThisAsEmailButtonSend.size = $ValueButtonSize  
$FormAdComputerInfoSendThisAsEmailButtonSend.Add_Click({ FormAdComputerInfoSendThisAsEmailButtonSend }) 
$FormAdComputerInfoSendThisAsEmail.Controls.Add($FormAdComputerInfoSendThisAsEmailButtonSend)
function FormAdComputerInfoSendThisAsEmailButtonSend {
$SmtpServer = $SmtpAdressToMailServer 
$SmtpUser = $ApplicationFormServiceUserId
$smtpPassword = $ApplicationFormServiceUserPassword
$SmtpUsername = $FormAdComputerInfoSendThisAsEmailTextbarUsername.text
$SmtpUsernameDomain = $SmtpFqdn
$MailtTo = $SmtpUsername + $SmtpUsernameDomain
$MailFrom = $ApplicationFormServiceUserId

$TextbarData = $ApplicationFormTextBarSearchBar.text
$ApplicationFormStatusBarStatusPanel.Text =  "Sending  AD-Information to user $MailtTo, Wait"
$MailSubject = "AD-Information on $TextbarData"
$AdcomputerSamaccountName = "$"
$TextbarDataSam = $TextbarData + $AdcomputerSamaccountName

$GetAdComputerAttributes = Get-ADComputer -Identity $TextbarData -Properties Name, Cn, DNSHostName, CanonicalName, SamAccountName, whenChanged, whenCreated, modifyTimeStamp, Enabled, OperatingSystem, OperatingSystemServicePack, OperatingSystemVersion, IPv4Address, LastLogonDate, LastLogon, badPasswordTime, ObjectSid, ObjectGuid | 
Format-list Name, Cn, DNSHostName, CanonicalName, SamAccountName, whenChanged, whenCreated, modifyTimeStamp, Enabled, OperatingSystem, OperatingSystemServicePack, OperatingSystemVersion, IPv4Address, LastLogonDate, LastLogonDate, @{N='LastLogon'; E={[DateTime]::FromFileTime($_.LastLogon)}}, @{N='badPasswordTime'; E={[DateTime]::FromFileTime($_.badPasswordTime)}}, ObjectSid, ObjectGuid | out-string;    
$GetGroupMembersCopyFromThisComputerSortName = Get-ADPrincipalGroupMembership $TextbarDataSam | sort name | select name | out-string;

$MailBody = "AD-Attributes $GetAdComputerAttributes AD-Groups $GetGroupMembersCopyFromThisComputerSortName"
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $SmtpUser, $($smtpPassword | ConvertTo-SecureString -AsPlainText -Force) 
Send-MailMessage -To "$MailtTo" -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8) -UseSsl -Credential $Credentials

$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$FormAdComputerInfoSendThisAsEmail.Close()}
###################
# Initlize FormAdComputerInfoSendThisAsEmail
$FormAdComputerInfoSendThisAsEmail.Add_Shown({$FormAdComputerInfoSendThisAsEmail.Activate()})
[void] $FormAdComputerInfoSendThisAsEmail.ShowDialog()}



######################################################################################
# Static Functions For Ad Computer Tab 
# 
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
function TextConfirmationAdComputer {
#$ApplicationFormProgressBar.Value = 0
$ApplicationFormProgressBar.Maximum = $total*4 + 4
}


#-------------------------------------------------------------------------------------#
#######################################################################################
#######################################################################################
#######################################################################################

#######################################################################################
############################# Active Directory Users  Tab #############################
#######################################################################################
$TabActiveDirectoryUser = New-object System.Windows.Forms.Tabpage
$TabActiveDirectoryUser.DataBindings.DefaultDataSourceUpdateMode = 0 
$TabActiveDirectoryUser.UseVisualStyleBackColor = $True 
$TabActiveDirectoryUser.Name = "TabActiveDirectoryUser" 
$TabActiveDirectoryUser.Text = "Active Directory User”
$FormTabControl.Controls.Add($TabActiveDirectoryUser)  

######################################################################################
# MainTab - Tabcontrol - TabADUser - RichTextbox 


#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$RichTextBoxActiveDirectoryUser = New-Object System.Windows.Forms.richtextbox
$RichTextBoxActiveDirectoryUser.Location = "5, 21"
$RichTextBoxActiveDirectoryUser.Name = "RichTextBoxADComputer"
$RichTextBoxActiveDirectoryUser.Size = "650, 418"
$RichTextBoxActiveDirectoryUser.ScrollBars = "Vertical" 
$RichTextBoxActiveDirectoryUser.font ="lucida console"
$TabActiveDirectoryUser.Controls.Add($RichTextBoxActiveDirectoryUser) 


######################################################################################
# MainTab - Tabcontrol - TabADUser Tab - Button 1 : Ad-Info
# Downloads a information from AD
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$TabActiveDirectoryUserInfo = New-object System.Windows.Forms.Button 
$TabActiveDirectoryUserInfo.text= "Ad-Info"   
$TabActiveDirectoryUserInfo.location = "670,20" 
$TabActiveDirectoryUserInfo.size = $ValueButtonSize  
$TabActiveDirectoryUserInfo.Add_Click({ BtnActiveDirectoryUserInfo }) 
$TabActiveDirectoryUser.Controls.Add($TabActiveDirectoryUserInfo) 
function BtnActiveDirectoryUserInfo {

$TextbarData = $ApplicationFormTextBarSearchBar.Text

# Powershell get-Aduser
$Usercheck = Get-ADUser -Identity $TextbarData
If ($Usercheck -eq $Null)  { $ApplicationFormStatusBarStatusPanel.text = "$TextbarData does not exist in AD" }
Else { 
TextFormProgressBarAduser
$ApplicationFormProgressBar.Value ++
$ApplicationFormStatusBarStatusPanel.Text = "Downloading Information From Ad, Wait"
$ApplicationFormProgressBar.Value ++

$GetAdUserAttributes  = Get-ADUser -Identity $TextbarData -Properties Name, whenCreated, DisplayName, CanonicalName, lsPersonnummer, lsPrivatEpost, mobile, telephoneNumber, lsQuotaAdm, lsQuotaPed, lsQuotaMail, Manager, lsAnsvar, lsVerksamhetDeb, lsAvtal, Office, lsChef, lsUppdateradAv, title, lsSITHS, LockedOut, PasswordLastSet, PasswordExpired, msDS-UserPasswordExpiryTimeComputed, LastBadPasswordAttempt, lsUniflowHomeDir, proxyAddresses | 
Format-List Name, whenCreated, DisplayName, CanonicalName, lsPersonnummer, lsPrivatEpost, mobile, telephoneNumber, lsQuotaAdm, lsQuotaPed, lsQuotaMail, Manager, lsAnsvar, lsVerksamhetDeb, lsAvtal, Office, lsChef, lsUppdateradAv, title, lsSITHS, LockedOut, PasswordLastSet, PasswordExpired, @{Name="ExpiryDate";Expression={[datetime]::FromFileTime($_."msDS-UserPasswordExpiryTimeComputed")}}, LastBadPasswordAttempt, lsUniflowHomeDir, proxyAddresses | out-string;

$GetAdUserOffice365Attributes = Get-ADUser -Identity $TextbarData -Properties extensionAttribute1, mail, msRTCSIP-PrimaryUserAddress, targetAddress, proxyAddresses | out-string 
Format-list extensionAttribute1, mail, msRTCSIP-PrimaryUserAddress, targetAddress, proxyAddresses | out-string 

$GetAdUserMembersOf = Get-ADPrincipalGroupMembership $TextbarData | sort name | select name | out-string

$RichTextBoxActiveDirectorGroups = "Ad-Groups"
$RichTextBoxActiveDirectorGroupsADAttributes = "Ad-Attributes"


# Export to the richtextbox
$RichTextBoxActiveDirectoryUser.text = $RichTextBoxActiveDirectorGroupsADAttributes+$GetAdUserAttributes + $RichTextBoxActiveDirectorGroups + $GetAdUserMembersOf 

$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
$ApplicationFormProgressBar.Value ++
start-sleep -m  100
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
 }}
 

 
 
 ######################################################################################
# MainTab - Tabcontrol - TabADUser Tab - Button 2 : Copy MembersOf
# Copies user1 membs of to user 2
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$TabActiveDirectoryUserCopyMembersOf = New-object System.Windows.Forms.Button 
$TabActiveDirectoryUserCopyMembersOf.text= "Copy Members"   
$TabActiveDirectoryUserCopyMembersOf.location = "670,41" 
$TabActiveDirectoryUserCopyMembersOf.size = $ValueButtonSize  
$TabActiveDirectoryUserCopyMembersOf.Add_Click({ BtnActiveDirectoryUserCopyMembersOf }) 
$TabActiveDirectoryUser.Controls.Add($TabActiveDirectoryUserCopyMembersOf) 
function BtnActiveDirectoryUserCopyMembersOf {

# Create the form
$FormActiveDirectoryUserCopyMembersOf = New-Object System.Windows.Forms.Form
$FormActiveDirectoryUserCopyMembersOf.Text = "Copy Members Of From User $textbardata" 
$FormActiveDirectoryUserCopyMembersOf.StartPosition = "CenterScreen"
$FormActiveDirectoryUserCopyMembersOf.Topmost = $false 
$FormActiveDirectoryUserCopyMembersOf.Size = "350,150"
$FormActiveDirectoryUserCopyMembersOf.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : Copy to User
$FormActiveDirectoryUserCopyMembersOfLabelCopyToUser = New-object System.Windows.Forms.Label   
$FormActiveDirectoryUserCopyMembersOfLabelCopyToUser.location = "100,5" 
$FormActiveDirectoryUserCopyMembersOfLabelCopyToUser.size = "250,20"
$FormActiveDirectoryUserCopyMembersOfLabelCopyToUser.text = "Copy To User"
$FormActiveDirectoryUserCopyMembersOf.Controls.Add($FormActiveDirectoryUserCopyMembersOfLabelCopyToUser)
# Textbar Username
$FormActiveDirectoryUserCopyMembersOfTextboxCopyToUser = New-object System.Windows.Forms.Textbox   
$FormActiveDirectoryUserCopyMembersOfTextboxCopyToUser.location = "5,30" 
$FormActiveDirectoryUserCopyMembersOfTextboxCopyToUser.size = "250,20"
$FormActiveDirectoryUserCopyMembersOf.Controls.Add($FormActiveDirectoryUserCopyMembersOfTextboxCopyToUser)
# Copy Button
$FormActiveDirectoryUserCopyMembersOfButtonCopyMembersOf = New-object System.Windows.Forms.Button 
$FormActiveDirectoryUserCopyMembersOfButtonCopyMembersOf.text= "Copy Members"   
$FormActiveDirectoryUserCopyMembersOfButtonCopyMembersOf.location = "265,30" 
$FormActiveDirectoryUserCopyMembersOfButtonCopyMembersOf.size = $ValueButtonSize  
$FormActiveDirectoryUserCopyMembersOfButtonCopyMembersOf.Add_Click({ ButtonCopyMembersOf }) 
$FormActiveDirectoryUserCopyMembersOf.Controls.Add($FormActiveDirectoryUserCopyMembersOfButtonCopyMembersOf)
function ButtonCopyMembersOf {
$TextbarData = $ApplicationFormTextBarSearchBar.Text
$CopymembersTo  = $FormActiveDirectoryUserCopyMembersOfTextboxCopyToUser.text


TextFormProgressBarAduser
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value ++

$CopyUserMembers = Get-ADUser -Identity $textbardata -Properties memberof | Select-Object -ExpandProperty memberof | Add-ADGroupMember -Members $CopymembersTo
$ApplicationFormStatusBarStatusPanel.text = "Copying $textbardata membersof to user $CopymembersTo"
$ApplicationFormStatusBarStatusPanel.text = "Task Completed"

$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$FormActiveDirectoryUserCopyMembersOf.Close()}



# Initlize FormActiveDirectoryUserCopyMembersOf
$FormActiveDirectoryUserCopyMembersOf.Add_Shown({$FormActiveDirectoryUserCopyMembersOf.Activate()})
[void] $FormActiveDirectoryUserCopyMembersOf.ShowDialog()}
 
######################################################################################
# MainTab - Tabcontrol - TabADUser Tab - Button 3 : Email Info
# Email user info
# Kunna se vart användaren är inloggad just nu, i vilken dator ( sccm fråga kanske ?)
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
 
$TabActiveDirectoryUserEmailUserInfo = New-object System.Windows.Forms.Button 
$TabActiveDirectoryUserEmailUserInfo.text= "Email Info "   
$TabActiveDirectoryUserEmailUserInfo.location = "670,62" 
$TabActiveDirectoryUserEmailUserInfo.size = $ValueButtonSize  
$TabActiveDirectoryUserEmailUserInfo.Add_Click({ BtnActiveDirectoryUserEmailInfo }) 
$TabActiveDirectoryUser.Controls.Add($TabActiveDirectoryUserEmailUserInfo) 
function BtnActiveDirectoryUserEmailInfo {
$TextbarData = $ApplicationFormTextBarSearchBar.Text
TextFormProgressBarAduser
$Usercheck = Get-ADUser -Identity $TextbarData
If ($Usercheck -eq $Null)  { $ApplicationFormStatusBarStatusPanel.text = "$TextbarData does not exist in AD" }
Else { 
# Skapa formuläret
$FormActiveDirectoryUserSendEmailUserInfo = New-Object System.Windows.Forms.Form
$FormActiveDirectoryUserSendEmailUserInfo.Text = "E-Mail User AD-Information" 
$FormActiveDirectoryUserSendEmailUserInfo.StartPosition = "CenterScreen"
$FormActiveDirectoryUserSendEmailUserInfo.Topmost = $false 
$FormActiveDirectoryUserSendEmailUserInfo.Size = "350,100"
$FormActiveDirectoryUserSendEmailUserInfo.Icon = New-Object system.drawing.icon ("$ApplicationIconPath")
# Label : Username
$FormActiveDirectoryUserSendEmailUserInfoLabelUsername = New-object System.Windows.Forms.Label   
$FormActiveDirectoryUserSendEmailUserInfoLabelUsername.location = "90,5" 
$FormActiveDirectoryUserSendEmailUserInfoLabelUsername.size = "250,20"
$FormActiveDirectoryUserSendEmailUserInfoLabelUsername.text = "Username"
$FormActiveDirectoryUserSendEmailUserInfo.Controls.Add($FormActiveDirectoryUserSendEmailUserInfoLabelUsername)
# Textbar Username
$FormActiveDirectoryUserSendEmailUserInfoTextbarUsername = New-object System.Windows.Forms.Textbox   
$FormActiveDirectoryUserSendEmailUserInfoTextbarUsername.location = "5,30" 
$FormActiveDirectoryUserSendEmailUserInfoTextbarUsername.size = "250,20"
$FormActiveDirectoryUserSendEmailUserInfo.Controls.Add($FormActiveDirectoryUserSendEmailUserInfoTextbarUsername)
# Send Button
$FormActiveDirectoryUserSendEmailUserInfoButtonSend = New-object System.Windows.Forms.Button 
$FormActiveDirectoryUserSendEmailUserInfoButtonSend.text= "Send E-Mail"   
$FormActiveDirectoryUserSendEmailUserInfoButtonSend.location = "265,30" 
$FormActiveDirectoryUserSendEmailUserInfoButtonSend.size = $ValueButtonSize  
$FormActiveDirectoryUserSendEmailUserInfoButtonSend.Add_Click({ FormActiveDirectoryUserSendEmailUserInfoButtonSend }) 
$FormActiveDirectoryUserSendEmailUserInfo.Controls.Add($FormActiveDirectoryUserSendEmailUserInfoButtonSend)
function FormActiveDirectoryUserSendEmailUserInfoButtonSend {
$SmtpServer = $SmtpAdressToMailServer 
$SmtpUser = $ApplicationFormServiceUserId
$smtpPassword = $ApplicationFormServiceUserPassword
$SmtpUsername = $FormActiveDirectoryUserSendEmailUserInfoTextbarUsername.text
$SmtpUsernameDomain = $SmtpFqdn
$MailtTo = $SmtpUsername + $SmtpUsernameDomain
$MailFrom = $ApplicationFormServiceUserId
$TextbarData = $ApplicationFormTextBarSearchBar.text
$ApplicationFormStatusBarStatusPanel.Text =  "Sending  AD-Information to user $MailtTo, Wait"
$MailSubject = "AD-Information on $TextbarData"


$GetAdUserAttributes  = Get-ADUser -Identity $TextbarData -Properties Name, whenCreated, DisplayName, CanonicalName, lsPersonnummer, lsPrivatEpost, mobile, telephoneNumber, lsQuotaAdm, lsQuotaPed, lsQuotaMail, Manager, lsAnsvar, lsVerksamhetDeb, lsAvtal, Office, lsChef, lsUppdateradAv, title, lsSITHS, LockedOut, PasswordLastSet, PasswordExpired, msDS-UserPasswordExpiryTimeComputed, LastBadPasswordAttempt, lsUniflowHomeDir, proxyAddresses | 
Format-List Name, whenCreated, DisplayName, CanonicalName, lsPersonnummer, lsPrivatEpost, mobile, telephoneNumber, lsQuotaAdm, lsQuotaPed, lsQuotaMail, Manager, lsAnsvar, lsVerksamhetDeb, lsAvtal, Office, lsChef, lsUppdateradAv, title, lsSITHS, LockedOut, PasswordLastSet, PasswordExpired, @{Name="ExpiryDate";Expression={[datetime]::FromFileTime($_."msDS-UserPasswordExpiryTimeComputed")}}, LastBadPasswordAttempt, lsUniflowHomeDir, proxyAddresses | out-string;

$GetAdUserMembersOf = Get-ADPrincipalGroupMembership $TextbarData | sort name | select name | out-string

$MailBody = "AD-Attributes $GetAdUserAttributes AD-Groups $GetAdUserMembersOf"
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $SmtpUser, $($smtpPassword | ConvertTo-SecureString -AsPlainText -Force) 
Send-MailMessage -To "$MailtTo" -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8) -UseSsl -Credential $Credentials

$ApplicationFormStatusBarStatusPanel.text = "Task Completed"
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
$FormActiveDirectoryUserSendEmailUserInfo.Close()}}
# Initlize FormActiveDirectoryUserSendEmailUserInfo
$FormActiveDirectoryUserSendEmailUserInfo.Add_Shown({$FormActiveDirectoryUserSendEmailUserInfo.Activate()})
[void] $FormActiveDirectoryUserSendEmailUserInfo.ShowDialog()}



######################################################################################
# MainTab - Tabcontrol - TabADUser Tab - Button 4 : Newpass
# New password form
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$TabActiveDirectoryUserNewPass = New-object System.Windows.Forms.Button 
$TabActiveDirectoryUserNewPass.text= "Password"   
$TabActiveDirectoryUserNewPass.location = "670,83" 
$TabActiveDirectoryUserNewPass.size = $ValueButtonSize  
$TabActiveDirectoryUserNewPass.Add_Click({ BtnActiveDirectoryUserNewpass }) 
$TabActiveDirectoryUser.Controls.Add($TabActiveDirectoryUserNewPass) 
function BtnActiveDirectoryUserNewpass {
$TextbarData = $ApplicationFormTextBarSearchBar.Text
# User check against AD
$Usercheck = Get-ADUser -Identity $TextbarData
If ($Usercheck -eq $Null)  { $ApplicationFormStatusBarStatusPanel.text = "$TextbarData does not exist in AD" }
Else { 


# Get the manager of the user
$GetManagerText = "Manager"
$Getmanager = Get-ADUser (Get-ADUser $textbardata -properties manager).manager -properties GivenName, Surname, SamAccountName | Format-table GivenName, Surname, SamAccountName | Out-string

# Query, Get the Colleagues of the user based on PhysicalDeliveryOfficeName
$GetColleaguesText = "Colleagues"
$Colleagues = Get-ADUser $textbardata -properties PhysicalDeliveryOfficeName | select PhysicalDeliveryOfficeName -ExpandProperty PhysicalDeliveryOfficeName
# String to the listview
$Info = Get-ADUser -LDAPFilter “(PhysicalDeliveryOfficeName=$Colleagues)" | Sort GivenName, Surname, SamAccountName | Format-table GivenName, Surname, SamAccountName | out-string

# Populate the Richtextbox with data
$RichTextBoxActiveDirectoryUser.text = $GetManagerText + $Getmanager + $GetColleaguesText + $Info 
# Start Aldpassword
Start-Process $PathNewPassExe

}}






######################################################################################
# MainTab - Tabcontrol - TabADUser Tab - Button 5 : Unlock
# Locks upp account

#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$TabActiveDirectoryUserUnlock = New-object System.Windows.Forms.Button 
$TabActiveDirectoryUserUnlock.text= "Unlock User"   
$TabActiveDirectoryUserUnlock.location = "670,104"  
$TabActiveDirectoryUserUnlock.size = $ValueButtonSize  
$TabActiveDirectoryUserUnlock.Add_Click({ BtnActiveDirectoryUserUnlock }) 
$TabActiveDirectoryUser.Controls.Add($TabActiveDirectoryUserUnlock) 
function BtnActiveDirectoryUserUnlock {
$TextbarData = $ApplicationFormTextBarSearchBar.Text

$Usercheck = Get-ADUser -Identity $TextbarData
If ($Usercheck -eq $Null)  { $ApplicationFormStatusBarStatusPanel.text = "$TextbarData does not exist in AD" }
Else { 
TextFormProgressBarAduser
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value ++
Unlock-ADAccount -Identity $TextbarData | out-string;
$ApplicationFormStatusBarStatusPanel.text = "Task Completed, Account $TextbarData is now unlocked"
$ApplicationFormProgressBar.Value ++
start-sleep -s 1
$ApplicationFormProgressBar.Value ++
$ApplicationFormProgressBar.Value = 0;
$ApplicationFormStatusBarStatusPanel.text = "Ready"
}}

######################################################################################
# Static Functions For Ad Computer Tab 
# 
#-----------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------#
function TextFormProgressBarAduser {
$ApplicationFormProgressBar.Maximum = $total*4 + 4
}





#-------------------------------------------------------------------------------------#
#######################################################################################
#######################################################################################
#######################################################################################

#######################################################################################
############################# Sccm  Tab ###############################################
####################################################################################### 

$TabSccm = New-object System.Windows.Forms.Tabpage
$TabSccm.DataBindings.DefaultDataSourceUpdateMode = 0 
$TabSccm.UseVisualStyleBackColor = $True 
$TabSccm.Name = "Sccm2012" 
$TabSccm.Text = "System Center 2012” 
$FormTabControl.Controls.Add($TabSccm)  

######################################################################################
# MainTab - Tabcontrol - Sccm - Listview 
#------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------#
$lvMainSccm = New-Object System.Windows.Forms.ListView
$lvMainSccm.Scrollable = $true 
$lvMainSccm.ContextMenuStrip = $ContextMenu
$lvMainSccm.FullRowSelect = $True
$lvMainSccm.GridLines = $True
$lvMainSccm.Location = "5, 21"
$lvMainSccm.Name = "lvMainSccm"
$lvMainSccm.Size = "650, 418"
$lvMainSccm.UseCompatibleStateImageBehavior = $False
$lvMainSccm.View = "Details"
$TabSccm.Controls.Add($lvMainSccm) 






#-------------------------------------------------------------------------------------#
#######################################################################################
#######################################################################################
#######################################################################################

#######################################################################################
############################## Initlize the form ######################################
####################################################################################### 

# Initlize the form
$ApplicationForm.Add_Shown({$ApplicationForm.Activate()})
[void] $ApplicationForm.ShowDialog()
